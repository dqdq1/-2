import { useState, useEffect } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import LevelSections from './components/LevelSections'
import Features from './components/Features'
import Footer from './components/Footer'
import WelcomeModal from './components/WelcomeModal'
import PaymentModal from './components/PaymentModal'
import LessonContent from './components/LessonContent'
import MiddleSchoolSection from './components/MiddleSchoolSection'
import HighSchoolSection from './components/HighSchoolSection'
import QuizSystem from './components/QuizSystem'
import CompetitionSystem from './components/CompetitionSystem'
import './App.css'

function App() {
  const [currentView, setCurrentView] = useState('home')
  const [selectedLevel, setSelectedLevel] = useState(null)
  const [selectedChapter, setSelectedChapter] = useState(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [hasPaid, setHasPaid] = useState(false)
  const [browsingStartTime, setBrowsingStartTime] = useState(null)

  useEffect(() => {
    // التحقق من حالة الدفع المحفوظة
    const paymentStatus = localStorage.getItem('zahraa_physics_payment_status')
    if (paymentStatus === 'paid') {
      setHasPaid(true)
    }
  }, [])

  useEffect(() => {
    // بدء عداد الـ 30 ثانية عند تسجيل الدخول
    if (isLoggedIn && !hasPaid && !browsingStartTime) {
      setBrowsingStartTime(Date.now())
      
      const timer = setTimeout(() => {
        setShowPaymentModal(true)
      }, 30000) // 30 ثانية

      return () => clearTimeout(timer)
    }
  }, [isLoggedIn, hasPaid, browsingStartTime])

  const handleLogin = (loginStatus) => {
    setIsLoggedIn(loginStatus)
  }

  const handlePayment = (method) => {
    // حفظ حالة الدفع
    localStorage.setItem('zahraa_physics_payment_status', 'paid')
    localStorage.setItem('zahraa_physics_payment_method', method)
    localStorage.setItem('zahraa_physics_payment_date', new Date().toISOString())
    
    setHasPaid(true)
    setShowPaymentModal(false)
    
    alert(`تم الدفع بنجاح عبر ${method === 'mastercard' ? 'ماستر كارد' : 'زين كاش'}! مرحباً بك في العضوية الكاملة`)
  }

  const handleStartLearning = (level) => {
    if (!isLoggedIn) {
      alert('يرجى تسجيل الدخول أولاً للوصول إلى المحتوى التعليمي')
      return
    }
    
    if (!hasPaid && browsingStartTime && (Date.now() - browsingStartTime) > 30000) {
      setShowPaymentModal(true)
      return
    }
    
    setSelectedLevel(level)
    setCurrentView('lesson')
  }

  const handleChapterSelect = (level, chapter) => {
    if (!isLoggedIn) {
      alert('يرجى تسجيل الدخول أولاً للوصول إلى المحتوى التعليمي')
      return
    }
    
    if (!hasPaid && browsingStartTime && (Date.now() - browsingStartTime) > 30000) {
      setShowPaymentModal(true)
      return
    }
    
    setSelectedLevel(level)
    setSelectedChapter(chapter)
    setCurrentView('lesson')
  }

  const handleNavigation = (view) => {
    if (!isLoggedIn && (view === 'levels' || view === 'middle-school' || view === 'high-school' || view === 'quiz' || view === 'competition')) {
      alert('يرجى تسجيل الدخول أولاً للوصول إلى المحتوى التعليمي')
      return
    }
    
    if (!hasPaid && browsingStartTime && (Date.now() - browsingStartTime) > 30000) {
      setShowPaymentModal(true)
      return
    }
    
    setCurrentView(view)
    if (view === 'home') {
      setSelectedLevel(null)
      setSelectedChapter(null)
    }
  }

  const handleBackToHome = () => {
    setCurrentView('home')
    setSelectedLevel(null)
    setSelectedChapter(null)
  }

  // عرض نافذة التسجيل إذا لم يسجل المستخدم
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center p-8">
          <div className="mb-8">
            <h1 className="text-6xl font-bold text-blue-800 mb-4 arabic-text">منصة المهندس</h1>
            <p className="text-xl text-gray-600 arabic-text">منصة تعليم الفيزياء المتخصصة</p>
            <div className="mt-4 flex justify-center space-x-4">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">📚 شروحات مفصلة</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">🎯 اختبارات تفاعلية</span>
              <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm">🏆 مسابقات تعليمية</span>
              <span className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm">🔬 تجارب علمية</span>
            </div>
          </div>
        </div>
        <WelcomeModal onLogin={handleLogin} />
      </div>
    )
  }

  // Render different views based on currentView
  if (currentView === 'lesson' && selectedLevel) {
    return (
      <>
        <div className="min-h-screen bg-gray-50">
          <Header onNavigate={handleNavigation} />
          <div className="pt-20">
            <LessonContent 
              level={selectedLevel} 
              chapter={selectedChapter}
              onBack={handleBackToHome} 
            />
          </div>
        </div>
        <PaymentModal 
          isOpen={showPaymentModal} 
          onClose={() => setShowPaymentModal(false)}
          onPayment={handlePayment}
        />
      </>
    )
  }

  if (currentView === 'quiz') {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header onNavigate={handleNavigation} />
        <div className="pt-20 pb-10">
          <div className="container mx-auto px-4">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-gray-800 mb-4">🎯 مركز الاختبارات</h1>
              <p className="text-xl text-gray-600">اختبر معرفتك في الفيزياء واحصل على تقييم فوري</p>
            </div>
            <QuizSystem level="beginner" type="lesson" />
          </div>
        </div>
        <PaymentModal 
          isOpen={showPaymentModal} 
          onClose={() => setShowPaymentModal(false)}
          onPayment={handlePayment}
        />
      </div>
    )
  }

  if (currentView === 'competition') {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header onNavigate={handleNavigation} />
        <div className="pt-20 pb-10">
          <div className="container mx-auto px-4">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-gray-800 mb-4">🏆 مركز المسابقات</h1>
              <p className="text-xl text-gray-600">تنافس مع الطلاب الآخرين واحصل على المراكز الأولى</p>
            </div>
            <CompetitionSystem level="beginner" />
          </div>
        </div>
        <PaymentModal 
          isOpen={showPaymentModal} 
          onClose={() => setShowPaymentModal(false)}
          onPayment={handlePayment}
        />
      </div>
    )
  }

  if (currentView === 'middle-school') {
    return (
      <div className="min-h-screen">
        <Header onNavigate={handleNavigation} />
        <div className="pt-16">
          <MiddleSchoolSection onChapterSelect={handleChapterSelect} />
        </div>
        <PaymentModal 
          isOpen={showPaymentModal} 
          onClose={() => setShowPaymentModal(false)}
          onPayment={handlePayment}
        />
      </div>
    )
  }

  if (currentView === 'high-school') {
    return (
      <div className="min-h-screen">
        <Header onNavigate={handleNavigation} />
        <div className="pt-16">
          <HighSchoolSection onChapterSelect={handleChapterSelect} />
        </div>
        <PaymentModal 
          isOpen={showPaymentModal} 
          onClose={() => setShowPaymentModal(false)}
          onPayment={handlePayment}
        />
      </div>
    )
  }

  if (currentView === 'levels') {
    return (
      <div className="min-h-screen">
        <Header onNavigate={handleNavigation} />
        <div className="pt-16">
          <LevelSections onStartLearning={handleStartLearning} />
        </div>
        <Footer />
        <PaymentModal 
          isOpen={showPaymentModal} 
          onClose={() => setShowPaymentModal(false)}
          onPayment={handlePayment}
        />
      </div>
    )
  }

  // Default home view
  return (
    <div className="min-h-screen">
      <Header onNavigate={handleNavigation} />
      <Hero onStartLearning={() => setCurrentView('levels')} />

      <Footer />
      <PaymentModal 
        isOpen={showPaymentModal} 
        onClose={() => setShowPaymentModal(false)}
        onPayment={handlePayment}
      />
    </div>
  )
}

export default App

