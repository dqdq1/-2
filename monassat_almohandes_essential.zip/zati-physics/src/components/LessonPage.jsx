import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ArrowLeft, ArrowRight, BookOpen, CheckCircle, Clock, Target } from 'lucide-react'

const LessonPage = ({ lesson, onNext, onPrevious }) => {
  const [currentSection, setCurrentSection] = useState(0)
  const [completedSections, setCompletedSections] = useState(new Set())

  const markSectionComplete = (sectionIndex) => {
    setCompletedSections(prev => new Set([...prev, sectionIndex]))
  }

  const sections = [
    {
      title: "مقدمة",
      content: "مرحباً بك في درس قوانين نيوتن للحركة. في هذا الدرس سنتعلم القوانين الثلاثة الأساسية التي تحكم حركة الأجسام.",
      image: "/src/assets/images/classical_mechanics/newton_laws_1.jpg"
    },
    {
      title: "القانون الأول",
      content: "القانون الأول لنيوتن ينص على أن الجسم الساكن يبقى ساكناً، والجسم المتحرك يبقى متحركاً بسرعة ثابتة في خط مستقيم، ما لم تؤثر عليه قوة خارجية.",
      image: "/src/assets/images/classical_mechanics/newton_laws_2.png"
    },
    {
      title: "القانون الثاني",
      content: "القانون الثاني ينص على أن القوة المحصلة تساوي الكتلة مضروبة في التسارع: F = ma",
      image: "/src/assets/images/classical_mechanics/newton_laws_3.jpg"
    },
    {
      title: "القانون الثالث",
      content: "لكل فعل رد فعل مساوٍ له في المقدار ومضاد له في الاتجاه.",
      image: "/src/assets/images/classical_mechanics/newton_laws_4.png"
    }
  ]

  const quiz = {
    question: "ما هو القانون الأول لنيوتن؟",
    options: [
      "F = ma",
      "الجسم الساكن يبقى ساكناً والمتحرك يبقى متحركاً ما لم تؤثر عليه قوة",
      "لكل فعل رد فعل مساوٍ ومضاد",
      "الطاقة محفوظة"
    ],
    correct: 1
  }

  const [selectedAnswer, setSelectedAnswer] = useState(null)
  const [showResult, setShowResult] = useState(false)

  const handleAnswerSelect = (index) => {
    setSelectedAnswer(index)
    setShowResult(true)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 space-x-reverse">
              <BookOpen className="h-6 w-6 text-blue-600" />
              <div className="arabic-text">
                <h1 className="text-xl font-bold text-gray-800">قوانين نيوتن للحركة</h1>
                <p className="text-sm text-gray-600">الميكانيكا الكلاسيكية</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                <span>30 دقيقة</span>
              </div>
              <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600">
                <Target className="h-4 w-4" />
                <span>{completedSections.size}/{sections.length + 1} مكتمل</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle className="arabic-text">محتويات الدرس</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {sections.map((section, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentSection(index)}
                      className={`w-full text-right p-3 rounded-lg transition-colors arabic-text ${
                        currentSection === index
                          ? 'bg-blue-100 text-blue-800 border border-blue-200'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm">{section.title}</span>
                        {completedSections.has(index) && (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        )}
                      </div>
                    </button>
                  ))}
                  <button
                    onClick={() => setCurrentSection(sections.length)}
                    className={`w-full text-right p-3 rounded-lg transition-colors arabic-text ${
                      currentSection === sections.length
                        ? 'bg-blue-100 text-blue-800 border border-blue-200'
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm">اختبار سريع</span>
                      {completedSections.has(sections.length) && (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      )}
                    </div>
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {currentSection < sections.length ? (
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl arabic-text">
                    {sections[currentSection].title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {sections[currentSection].image && (
                      <div className="flex justify-center">
                        <img
                          src={sections[currentSection].image}
                          alt={sections[currentSection].title}
                          className="max-w-full h-auto rounded-lg shadow-md"
                        />
                      </div>
                    )}
                    <p className="text-lg leading-relaxed arabic-text">
                      {sections[currentSection].content}
                    </p>
                    
                    <div className="flex justify-between items-center pt-6 border-t">
                      <Button
                        variant="outline"
                        onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
                        disabled={currentSection === 0}
                        className="arabic-text"
                      >
                        <ArrowRight className="ml-2 h-4 w-4" />
                        السابق
                      </Button>
                      
                      <Button
                        onClick={() => {
                          markSectionComplete(currentSection)
                          setCurrentSection(Math.min(sections.length, currentSection + 1))
                        }}
                        className="arabic-text"
                      >
                        التالي
                        <ArrowLeft className="mr-2 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              // Quiz Section
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl arabic-text">اختبار سريع</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <h3 className="text-xl font-semibold arabic-text">{quiz.question}</h3>
                    
                    <div className="space-y-3">
                      {quiz.options.map((option, index) => (
                        <button
                          key={index}
                          onClick={() => handleAnswerSelect(index)}
                          disabled={showResult}
                          className={`w-full p-4 text-right rounded-lg border transition-colors arabic-text ${
                            showResult
                              ? index === quiz.correct
                                ? 'bg-green-100 border-green-500 text-green-800'
                                : index === selectedAnswer
                                ? 'bg-red-100 border-red-500 text-red-800'
                                : 'bg-gray-50 border-gray-200'
                              : 'hover:bg-blue-50 border-gray-200'
                          }`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>

                    {showResult && (
                      <div className={`p-4 rounded-lg ${
                        selectedAnswer === quiz.correct
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        <p className="arabic-text">
                          {selectedAnswer === quiz.correct
                            ? '🎉 إجابة صحيحة! أحسنت'
                            : '❌ إجابة خاطئة. الإجابة الصحيحة هي: ' + quiz.options[quiz.correct]
                          }
                        </p>
                      </div>
                    )}

                    <div className="flex justify-between items-center pt-6 border-t">
                      <Button
                        variant="outline"
                        onClick={() => setCurrentSection(currentSection - 1)}
                        className="arabic-text"
                      >
                        <ArrowRight className="ml-2 h-4 w-4" />
                        السابق
                      </Button>
                      
                      {showResult && (
                        <Button
                          onClick={() => {
                            markSectionComplete(sections.length)
                            // Navigate to next lesson or course completion
                          }}
                          className="arabic-text"
                        >
                          إنهاء الدرس
                          <CheckCircle className="mr-2 h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default LessonPage

