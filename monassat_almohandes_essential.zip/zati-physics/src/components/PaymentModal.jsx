import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { CreditCard, Smartphone, Phone, X, Clock } from 'lucide-react'

const PaymentModal = ({ isOpen, onClose, onPayment }) => {
  const [selectedMethod, setSelectedMethod] = useState(null)
  const [isProcessing, setIsProcessing] = useState(false)

  const handlePayment = (method) => {
    setIsProcessing(true)
    
    // محاكاة عملية الدفع
    setTimeout(() => {
      setIsProcessing(false)
      onPayment(method)
      onClose()
    }, 3000)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center relative">
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="absolute left-2 top-2"
            disabled={isProcessing}
          >
            <X className="h-4 w-4" />
          </Button>
          <div className="flex items-center justify-center mb-4">
            <Clock className="h-12 w-12 text-orange-600" />
          </div>
          <CardTitle className="text-2xl arabic-text text-orange-800">
            انتهت فترة التصفح المجاني
          </CardTitle>
          <CardDescription className="arabic-text text-lg">
            للمتابعة والوصول إلى جميع المحتويات التعليمية
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4">
              <p className="text-orange-800 arabic-text font-medium">
                ⏰ لقد انتهت فترة التصفح المجاني (30 ثانية)
              </p>
              <p className="text-orange-700 arabic-text text-sm mt-2">
                للمتابعة، يرجى اختيار إحدى طرق الدفع أدناه
              </p>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="space-y-4">
            {/* Master Card */}
            <Card 
              className={`cursor-pointer transition-all ${
                selectedMethod === 'mastercard' 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'hover:border-gray-300'
              }`}
              onClick={() => setSelectedMethod('mastercard')}
            >
              <CardContent className="p-4">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <CreditCard className="h-8 w-8 text-blue-600" />
                  <div className="flex-1">
                    <h3 className="font-semibold arabic-text">بطاقة ماستر كارد</h3>
                    <p className="text-sm text-gray-600 arabic-text">
                      الدفع الآمن عبر بطاقة ماستر كارد
                    </p>
                    <p className="text-xs text-blue-600 arabic-text font-medium">
                      📞 للتحويل: 07739400501
                    </p>
                  </div>
                  {selectedMethod === 'mastercard' && (
                    <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Zain Cash */}
            <Card 
              className={`cursor-pointer transition-all ${
                selectedMethod === 'zaincash' 
                  ? 'border-purple-500 bg-purple-50' 
                  : 'hover:border-gray-300'
              }`}
              onClick={() => setSelectedMethod('zaincash')}
            >
              <CardContent className="p-4">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <Smartphone className="h-8 w-8 text-purple-600" />
                  <div className="flex-1">
                    <h3 className="font-semibold arabic-text">زين كاش</h3>
                    <p className="text-sm text-gray-600 arabic-text">
                      التحويل السريع عبر زين كاش
                    </p>
                    <p className="text-xs text-purple-600 arabic-text font-medium">
                      📱 للتحويل: 07739400501
                    </p>
                  </div>
                  {selectedMethod === 'zaincash' && (
                    <div className="w-4 h-4 bg-purple-500 rounded-full"></div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Button */}
          <Button
            onClick={() => handlePayment(selectedMethod)}
            disabled={!selectedMethod || isProcessing}
            className="w-full arabic-text"
            size="lg"
          >
            {isProcessing ? (
              'جاري معالجة الدفع...'
            ) : selectedMethod ? (
              `الدفع عبر ${selectedMethod === 'mastercard' ? 'ماستر كارد' : 'زين كاش'}`
            ) : (
              'اختر طريقة الدفع'
            )}
          </Button>

          {/* Contact Info */}
          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <h4 className="font-semibold text-green-800 mb-2 arabic-text flex items-center">
              <Phone className="h-4 w-4 ml-2" />
              معلومات التحويل
            </h4>
            <div className="space-y-1 text-sm text-green-700 arabic-text">
              <p>📞 <strong>رقم الهاتف:</strong> 07739400501</p>
              <p>💳 <strong>ماستر كارد:</strong> متاح للتحويل المباشر</p>
              <p>📱 <strong>زين كاش:</strong> تحويل فوري وآمن</p>
            </div>
          </div>

          {/* Pricing */}
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <h4 className="font-semibold text-blue-800 mb-2 arabic-text">باقات الاشتراك:</h4>
            <div className="space-y-2 text-sm text-blue-700 arabic-text">
              <div className="flex justify-between">
                <span>اشتراك شهري</span>
                <span className="font-semibold">10,000 د.ع</span>
              </div>
              <div className="flex justify-between">
                <span>اشتراك سنوي (خصم 20%)</span>
                <span className="font-semibold">96,000 د.ع</span>
              </div>
              <div className="flex justify-between border-t pt-2">
                <span className="font-semibold">الوصول الكامل لجميع المحتويات</span>
                <span className="text-green-600">✓</span>
              </div>
            </div>
          </div>

          {/* Support */}
          <p className="text-xs text-gray-500 text-center arabic-text">
            للمساعدة أو الاستفسار، تواصل معنا على{' '}
            <span className="font-semibold">07739400501</span>
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

export default PaymentModal

