import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Facebook, Mail, X } from 'lucide-react'

const LoginModal = ({ isOpen, onClose }) => {
  const [isLoading, setIsLoading] = useState(false)

  if (!isOpen) return null

  const handleSocialLogin = (provider) => {
    setIsLoading(true)
    // محاكاة عملية تسجيل الدخول
    setTimeout(() => {
      setIsLoading(false)
      alert(`تم تسجيل الدخول بنجاح عبر ${provider}!`)
      onClose()
    }, 2000)
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center relative">
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="absolute left-2 top-2"
          >
            <X className="h-4 w-4" />
          </Button>
          <CardTitle className="text-2xl arabic-text">مرحباً بك في Zahraa Physics</CardTitle>
          <CardDescription className="arabic-text">
            سجل دخولك للوصول إلى جميع الدروس والميزات
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Facebook Login */}
          <Button
            onClick={() => handleSocialLogin('Facebook')}
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white arabic-text"
            size="lg"
          >
            <Facebook className="ml-2 h-5 w-5" />
            {isLoading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول عبر فيسبوك'}
          </Button>

          {/* Google Login */}
          <Button
            onClick={() => handleSocialLogin('Google')}
            disabled={isLoading}
            variant="outline"
            className="w-full arabic-text"
            size="lg"
          >
            <Mail className="ml-2 h-5 w-5" />
            {isLoading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول عبر جوجل'}
          </Button>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-gray-500 arabic-text">أو</span>
            </div>
          </div>

          {/* Guest Access */}
          <Button
            onClick={() => {
              alert('يمكنك تصفح المحتوى المجاني بدون تسجيل!')
              onClose()
            }}
            variant="ghost"
            className="w-full arabic-text"
          >
            تصفح كضيف
          </Button>

          {/* Terms */}
          <p className="text-xs text-gray-500 text-center arabic-text">
            بتسجيل الدخول، أنت توافق على{' '}
            <a href="#" className="text-blue-600 hover:underline">
              شروط الاستخدام
            </a>{' '}
            و{' '}
            <a href="#" className="text-blue-600 hover:underline">
              سياسة الخصوصية
            </a>
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

export default LoginModal

