import { Button } from '@/components/ui/button'
import { ArrowLeft, Play } from 'lucide-react'

const Hero = ({ onStartLearning }) => {
  return (
    <section id="home" className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-64 h-64 bg-blue-400 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-400 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-128 h-128 bg-blue-300 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 arabic-text">
            تعلم الفيزياء
            <br />
            <span className="text-yellow-400">من الصفر إلى الاحتراف</span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 text-blue-100 arabic-text leading-relaxed">
            رحلتك في عالم الفيزياء تبدأ من هنا. اكتشف أسرار الكون من خلال دروس 
            تفاعلية وتمارين محلولة
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button 
              size="lg" 
              className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold px-8 py-4 text-lg arabic-text"
              onClick={() => onStartLearning('levels')}
            >
              <ArrowLeft className="ml-2 h-5 w-5" />
              ابدأ التعلم الآن
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-blue-900 px-8 py-4 text-lg arabic-text"
            >
              <Play className="ml-2 h-5 w-5" />
              شاهد الفيديو التعريفي
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-yellow-400 mb-2">100+</div>
              <div className="text-blue-200 arabic-text">درس تفاعلي</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-yellow-400 mb-2">500+</div>
              <div className="text-blue-200 arabic-text">تمرين محلول</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-yellow-400 mb-2">50+</div>
              <div className="text-blue-200 arabic-text">اختبار تقييمي</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero

