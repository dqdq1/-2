import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { BookOpen, Calculator, Trophy, Users, Clock, Target } from 'lucide-react'

const Features = () => {
  const features = [
    {
      icon: <BookOpen className="h-8 w-8 text-blue-600" />,
      title: 'دروس تفاعلية',
      description: 'تعلم من خلال دروس مصممة بعناية مع أمثلة عملية ورسوم توضيحية'
    },
    {
      icon: <Calculator className="h-8 w-8 text-green-600" />,
      title: 'تمارين محلولة',
      description: 'مئات التمارين مع حلول مفصلة خطوة بخطوة لتعزيز فهمك'
    },
    {
      icon: <Trophy className="h-8 w-8 text-yellow-600" />,
      title: 'اختبارات تقييمية',
      description: 'قيم مستواك من خلال اختبارات شاملة واحصل على شهادات إنجاز'
    },
    {
      icon: <Users className="h-8 w-8 text-purple-600" />,
      title: 'مجتمع تعليمي',
      description: 'انضم إلى مجتمع من المتعلمين وشارك الأسئلة والإجابات'
    },
    {
      icon: <Clock className="h-8 w-8 text-red-600" />,
      title: 'تعلم بوتيرتك',
      description: 'ادرس في أي وقت ومن أي مكان بالسرعة التي تناسبك'
    },
    {
      icon: <Target className="h-8 w-8 text-indigo-600" />,
      title: 'مسار مخصص',
      description: 'احصل على مسار تعليمي مخصص حسب مستواك وأهدافك'
    }
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4 arabic-text">
            لماذا تختار ذاتي؟
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto arabic-text">
            نوفر لك أفضل تجربة تعليمية في الفيزياء مع أدوات متقدمة وطرق تدريس حديثة
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {features.map((feature, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 border-0 shadow-md">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 p-3 bg-gray-50 rounded-full w-fit group-hover:bg-blue-50 transition-colors">
                  {feature.icon}
                </div>
                <CardTitle className="text-xl font-bold text-gray-800 arabic-text">
                  {feature.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 arabic-text leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Statistics */}
        <div className="mt-20 bg-gradient-to-r from-blue-600 to-blue-800 rounded-2xl p-8 md:p-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center text-white">
            <div>
              <div className="text-4xl md:text-5xl font-bold mb-2">10,000+</div>
              <div className="text-lg arabic-text opacity-90">طالب نشط</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold mb-2">500+</div>
              <div className="text-lg arabic-text opacity-90">درس تفاعلي</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold mb-2">1,000+</div>
              <div className="text-lg arabic-text opacity-90">تمرين محلول</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold mb-2">95%</div>
              <div className="text-lg arabic-text opacity-90">معدل الرضا</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Features

