import { BookOpen, Mail, Phone, MapPin, Facebook, Twitter, Youtube, Instagram } from 'lucide-react'

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 space-x-reverse mb-4">
              <BookOpen className="h-8 w-8 text-blue-400" />
              <span className="text-2xl font-bold arabic-text">Zahraa Physics</span>
            </div>
            <p className="text-gray-300 arabic-text leading-relaxed">
              منصة تعليمية متخصصة في تدريس الفيزياء من الصفر إلى الاحتراف بطريقة تفاعلية وممتعة
            </p>
            <div className="flex space-x-4 space-x-reverse mt-6">
              <a href="https://facebook.com/zahraa.physics" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-pink-400 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 arabic-text">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="text-gray-300 hover:text-white transition-colors arabic-text">
                  الرئيسية
                </a>
              </li>
              <li>
                <a href="#levels" className="text-gray-300 hover:text-white transition-colors arabic-text">
                  المستويات
                </a>
              </li>
              <li>
                <a href="#about" className="text-gray-300 hover:text-white transition-colors arabic-text">
                  عن الموقع
                </a>
              </li>
              <li>
                <a href="#contact" className="text-gray-300 hover:text-white transition-colors arabic-text">
                  اتصل بنا
                </a>
              </li>
            </ul>
          </div>

          {/* Levels */}
          <div>
            <h3 className="text-lg font-semibold mb-4 arabic-text">المستويات</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors arabic-text">
                  مستوى المبتدئين
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors arabic-text">
                  مستوى المتوسطين
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors arabic-text">
                  مستوى المحترفين
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors arabic-text">
                  اختبار تحديد المستوى
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4 arabic-text">تواصل معنا</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 space-x-reverse">
                <Mail className="h-5 w-5 text-blue-400" />
                <span className="text-gray-300">info@zahraa-physics.com</span>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <Phone className="h-5 w-5 text-blue-400" />
                <span className="text-gray-300" dir="ltr">٠٧٧٣٩٤٠٠٥٠١</span>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <Facebook className="h-5 w-5 text-blue-400" />
                <a href="https://facebook.com/zahraa.physics" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white transition-colors arabic-text">
                  Zahraa Physics
                </a>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <MapPin className="h-5 w-5 text-blue-400" />
                <span className="text-gray-300 arabic-text">العراق، بغداد</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 arabic-text">
            © 2024 Zahraa Physics. جميع الحقوق محفوظة.
          </p>
          <div className="flex space-x-6 space-x-reverse mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-white transition-colors arabic-text">
              سياسة الخصوصية
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors arabic-text">
              شروط الاستخدام
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

