import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { marked } from 'marked';
import QuizSystem from './QuizSystem';
import CompetitionSystem from './CompetitionSystem';
import ExperimentComponent from './ExperimentComponent';

const LessonContent = () => {
  const { level, chapter } = useParams();
  const [content, setContent] = useState('');
  const [activeTab, setActiveTab] = useState('explanation');

  useEffect(() => {
    const fetchContent = async () => {
      try {
        let filePath = '';
        if (level === 'middle_school') {
          filePath = `/content/middle_school_physics/${chapter}_explanation.md`;
        } else if (level === 'high_school') {
          filePath = `/content/high_school_physics/${chapter}_explanation.md`;
        } else {
          filePath = `/content/${chapter}.md`;
        }
        const response = await fetch(filePath);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const text = await response.text();
        setContent(marked.parse(text));
      } catch (error) {
        console.error("Error fetching content:", error);
        setContent('<p>حدث خطأ أثناء تحميل المحتوى. يرجى المحاولة مرة أخرى لاحقًا.</p>');
      }
    };

    fetchContent();
  }, [level, chapter]);

  const getLevelForQuiz = () => {
    if (level === 'middle_school') return 'beginner';
    if (level === 'high_school') return 'intermediate';
    return level;
  };

  return (
    <div className="container mx-auto p-4">
      <div className="flex border-b border-gray-200 mb-6">
        <button
          className={`py-3 px-6 font-medium transition-colors ${
            activeTab === 'explanation' 
              ? 'border-b-2 border-blue-500 text-blue-600 bg-blue-50' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setActiveTab('explanation')}
        >
          📚 الشروحات
        </button>
        <button
          className={`py-3 px-6 font-medium transition-colors ${
            activeTab === 'quiz' 
              ? 'border-b-2 border-blue-500 text-blue-600 bg-blue-50' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setActiveTab('quiz')}
        >
          📝 الاختبارات
        </button>
        <button
          className={`py-3 px-6 font-medium transition-colors ${
            activeTab === 'competition' 
              ? 'border-b-2 border-blue-500 text-blue-600 bg-blue-50' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setActiveTab('competition')}
        >
          🏆 المسابقات
        </button>
        <button
          className={`py-3 px-6 font-medium transition-colors ${
            activeTab === 'experiment' 
              ? 'border-b-2 border-blue-500 text-blue-600 bg-blue-50' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setActiveTab('experiment')}
        >
          🔬 التجارب
        </button>
      </div>

      <div className="mt-6">
        {activeTab === 'explanation' && (
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <div 
              className="prose max-w-none prose-lg prose-blue" 
              style={{ direction: 'rtl', textAlign: 'right' }}
              dangerouslySetInnerHTML={{ __html: content }} 
            />
          </div>
        )}
        
        {activeTab === 'quiz' && (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-gray-800 mb-2">🎯 اختبارات تفاعلية</h2>
              <p className="text-gray-600">اختبر معرفتك واحصل على تغذية راجعة فورية</p>
            </div>
            <QuizSystem 
              level={getLevelForQuiz()} 
              chapter={chapter} 
              type="lesson" 
            />
          </div>
        )}
        
        {activeTab === 'competition' && (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-gray-800 mb-2">🏆 مسابقات تعليمية</h2>
              <p className="text-gray-600">تحدى نفسك وتنافس مع الآخرين</p>
            </div>
            <CompetitionSystem level={getLevelForQuiz()} />
          </div>
        )}
        
        {activeTab === 'experiment' && (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-gray-800 mb-2">🔬 تجارب علمية تفاعلية</h2>
              <p className="text-gray-600">اكتشف القوانين الفيزيائية من خلال التجارب العملية</p>
            </div>
            <ExperimentComponent level={getLevelForQuiz()} />
          </div>
        )}
      </div>
    </div>
  );
};

export default LessonContent;

