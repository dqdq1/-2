import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { BookOpen, FileText, CheckCircle } from 'lucide-react'
import { useState } from 'react'

const MiddleSchoolSection = ({ onNavigate }) => {
  const [selectedChapter, setSelectedChapter] = useState(null)

  const chapters = [
    { id: 1, title: "الكهربائية الساكنة", description: "شرح مفصل للشحنات الكهربائية والقوانين الأساسية" },
    { id: 2, title: "المغناطيسية", description: "المغناطيس والمواد المغناطيسية والمجال المغناطيسي" },
    { id: 3, title: "التيار الكهربائي", description: "قانون أوم والمقاومة الكهربائية وربط المقاومات" },
    { id: 4, title: "البطارية والقوة الدافعة الكهربائية", description: "أنواع البطاريات والدوائر الكهربائية" },
    { id: 5, title: "القدرة والطاقة الكهربائية", description: "حساب القدرة والطاقة والكلفة الاقتصادية" },
    { id: 6, title: "الكهرومغناطيسية", description: "العلاقة بين الكهرباء والمغناطيسية" },
    { id: 7, title: "المحولة الكهربائية", description: "مبدأ عمل المحولة وأنواعها" },
    { id: 8, title: "تكنولوجيا مصادر الطاقة", description: "مصادر الطاقة المتجددة وغير المتجددة" },
    { id: 9, title: "فيزياء الجو وتقنية الاتصالات", description: "الغلاف الجوي والاتصالات الحديثة" }
  ]

  const handleChapterClick = (chapter) => {
    setSelectedChapter(chapter)
  }

  const handleBackToChapters = () => {
    setSelectedChapter(null)
  }

  if (selectedChapter) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="max-w-4xl mx-auto">
          <Button 
            onClick={handleBackToChapters}
            className="mb-6 bg-blue-600 hover:bg-blue-700"
          >
            ← العودة للفصول
          </Button>
          
          <Card className="mb-6">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
              <CardTitle className="text-2xl text-right">
                الفصل {selectedChapter.id}: {selectedChapter.title}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-2 border-blue-200 hover:border-blue-400 transition-colors">
                  <CardHeader className="bg-blue-50">
                    <CardTitle className="flex items-center gap-2 text-blue-700 text-right">
                      <BookOpen className="w-5 h-5" />
                      الشروحات المختصرة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <p className="text-gray-600 text-right mb-4">
                      شروحات واضحة ومبسطة للمفاهيم الأساسية في الفصل
                    </p>
                    <Button 
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={() => window.open(`/content/middle_school_physics/chapter${selectedChapter.id}_explanation.md`, '_blank')}
                    >
                      عرض الشروحات
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-2 border-green-200 hover:border-green-400 transition-colors">
                  <CardHeader className="bg-green-50">
                    <CardTitle className="flex items-center gap-2 text-green-700 text-right">
                      <FileText className="w-5 h-5" />
                      حلول أسئلة الفصل
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <p className="text-gray-600 text-right mb-4">
                      حلول مفصلة لجميع أسئلة الفصل مع التعليلات
                    </p>
                    <Button 
                      className="w-full bg-green-600 hover:bg-green-700"
                      onClick={() => window.open(`/content/middle_school_physics/chapter${selectedChapter.id}_explanation.md`, '_blank')}
                    >
                      عرض الحلول
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h3 className="text-lg font-semibold text-yellow-800 text-right mb-2">
                  💡 نصائح للدراسة
                </h3>
                <ul className="text-yellow-700 text-right space-y-1">
                  <li>• اقرأ الشروحات أولاً لفهم المفاهيم الأساسية</li>
                  <li>• حل الأسئلة بنفسك قبل مراجعة الحلول</li>
                  <li>• راجع التعليلات لفهم الأسباب العلمية</li>
                  <li>• اربط المفاهيم بالتطبيقات العملية</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            فيزياء الثالث المتوسط
          </h1>
          <p className="text-xl text-gray-600">
            شروحات مختصرة وحلول أسئلة الفصل
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {chapters.map((chapter) => (
            <Card 
              key={chapter.id}
              className="hover:shadow-lg transition-shadow cursor-pointer border-2 border-blue-200 hover:border-blue-400"
              onClick={() => handleChapterClick(chapter)}
            >
              <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
                <CardTitle className="text-right">
                  الفصل {chapter.id}
                </CardTitle>
                <h3 className="text-lg font-semibold text-right">
                  {chapter.title}
                </h3>
              </CardHeader>
              <CardContent className="p-4">
                <p className="text-gray-600 text-right mb-4">
                  {chapter.description}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span className="text-sm">متوفر</span>
                  </div>
                  <Button 
                    size="sm" 
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    ادخل للفصل
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Button 
            onClick={() => onNavigate('home')}
            variant="outline"
            className="border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            العودة للصفحة الرئيسية
          </Button>
        </div>
      </div>
    </div>
  )
}

export default MiddleSchoolSection

