import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Menu, X, BookOpen, User, GraduationCap, School } from 'lucide-react'
import LoginModal from './LoginModal'

const Header = ({ onNavigate }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const handleLogin = () => {
    setIsLoginModalOpen(true)
  }

  const handleNavigation = (page) => {
    if (onNavigate) {
      onNavigate(page)
    }
    setIsMenuOpen(false)
  }

  return (
    <>
      <header className="bg-white shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-2 space-x-reverse cursor-pointer" onClick={() => handleNavigation('home')}>
              <BookOpen className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold text-blue-800 arabic-text">منصة المهندس</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8 space-x-reverse arabic-text">
              <button 
                onClick={() => handleNavigation('home')}
                className="text-gray-700 hover:text-blue-600 transition-colors"
              >
                الرئيسية
              </button>
              <button 
                onClick={() => handleNavigation('levels')}
                className="text-gray-700 hover:text-blue-600 transition-colors"
              >
                المستويات
              </button>
              <div className="relative group">
                <button className="text-gray-700 hover:text-blue-600 transition-colors flex items-center gap-1">
                  المناهج الدراسية
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                  <div className="py-1">
                    <button
                      onClick={() => handleNavigation('middle-school')}
                      className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 w-full text-right"
                    >
                      <School className="w-4 h-4" />
                      الثالث المتوسط
                    </button>
                    <button
                      onClick={() => handleNavigation('high-school')}
                      className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 w-full text-right"
                    >
                      <GraduationCap className="w-4 h-4" />
                      السادس الإعدادي
                    </button>
                  </div>
                </div>
              </div>
              <a href="#about" className="text-gray-700 hover:text-blue-600 transition-colors">
                عن الموقع
              </a>
              <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors">
                اتصل بنا
              </a>
            </nav>

            {/* Login Button */}
            <div className="hidden md:flex">
              <Button onClick={handleLogin} className="arabic-text">
                <User className="ml-2 h-4 w-4" />
                تسجيل الدخول
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleMenu}
                className="text-gray-700"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 border-t">
              <nav className="flex flex-col space-y-4 arabic-text">
                <button
                  onClick={() => handleNavigation('home')}
                  className="text-gray-700 hover:text-blue-600 transition-colors text-right"
                >
                  الرئيسية
                </button>
                <button
                  onClick={() => handleNavigation('levels')}
                  className="text-gray-700 hover:text-blue-600 transition-colors text-right"
                >
                  المستويات
                </button>
                <div className="border-t pt-2">
                  <p className="text-sm text-gray-500 mb-2 text-right">المناهج الدراسية:</p>
                  <button
                    onClick={() => handleNavigation('middle-school')}
                    className="flex items-center gap-2 text-gray-700 hover:text-blue-600 transition-colors text-right w-full py-1"
                  >
                    <School className="w-4 h-4" />
                    الثالث المتوسط
                  </button>
                  <button
                    onClick={() => handleNavigation('high-school')}
                    className="flex items-center gap-2 text-gray-700 hover:text-blue-600 transition-colors text-right w-full py-1"
                  >
                    <GraduationCap className="w-4 h-4" />
                    السادس الإعدادي
                  </button>
                </div>
                <a
                  href="#about"
                  className="text-gray-700 hover:text-blue-600 transition-colors text-right"
                  onClick={() => setIsMenuOpen(false)}
                >
                  عن الموقع
                </a>
                <a
                  href="#contact"
                  className="text-gray-700 hover:text-blue-600 transition-colors text-right"
                  onClick={() => setIsMenuOpen(false)}
                >
                  اتصل بنا
                </a>
                <Button onClick={handleLogin} className="arabic-text mt-4">
                  <User className="ml-2 h-4 w-4" />
                  تسجيل الدخول
                </Button>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Login Modal */}
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)} 
      />
    </>
  )
}

export default Header

