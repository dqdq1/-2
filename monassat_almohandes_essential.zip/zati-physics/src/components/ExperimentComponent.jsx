import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Play, RotateCcw, Zap, Activity, Thermometer } from 'lucide-react'

const ExperimentComponent = ({ level, lessonId }) => {
  const [activeExperiment, setActiveExperiment] = useState(null)

  const experiments = {
    beginner: {
      1: [
        {
          id: 'gravity',
          title: 'تجربة السقوط الحر',
          description: 'اكتشف كيف تؤثر الجاذبية على الأجسام الساقطة',
          icon: Activity,
          component: GravityExperiment
        }
      ],
      2: [
        {
          id: 'measurement',
          title: 'تجربة القياس والوحدات',
          description: 'تعلم كيفية تحويل الوحدات المختلفة',
          icon: Activity,
          component: MeasurementExperiment
        }
      ],
      3: [
        {
          id: 'forces',
          title: 'تجربة القوى والحركة',
          description: 'اكتشف قوانين نيوتن من خلال التجربة',
          icon: Activity,
          component: ForcesExperiment
        }
      ]
    },
    intermediate: {
      1: [
        {
          id: 'energy',
          title: 'تجربة الطاقة والشغل',
          description: 'اكتشف العلاقة بين الطاقة الحركية والكامنة',
          icon: Activity,
          component: EnergyExperiment
        }
      ],
      2: [
        {
          id: 'ohm',
          title: 'تجربة قانون أوم',
          description: 'اكتشف العلاقة بين الجهد والتيار والمقاومة',
          icon: Zap,
          component: OhmLawExperiment
        },
        {
          id: 'kirchhoff',
          title: 'تجربة قوانين كيرشوف',
          description: 'تعلم تحليل الدوائر الكهربائية المعقدة',
          icon: Zap,
          component: KirchhoffExperiment
        }
      ]
    },
    advanced: {
      1: [
        {
          id: 'relativity',
          title: 'محاكاة النسبية الخاصة',
          description: 'اكتشف تأثيرات النسبية على الزمن والمكان',
          icon: Activity,
          component: RelativityExperiment
        }
      ],
      2: [
        {
          id: 'quantum',
          title: 'محاكاة الظواهر الكمية',
          description: 'استكشف عالم ميكانيكا الكم الغريب',
          icon: Activity,
          component: QuantumExperiment
        }
      ]
    }
  }

  const currentExperiments = experiments[level]?.[lessonId] || []

  if (currentExperiments.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-600 arabic-text">لا توجد تجارب متاحة لهذا الدرس حالياً</p>
      </div>
    )
  }

  if (activeExperiment) {
    const ExperimentComponent = activeExperiment.component
    return (
      <div>
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={() => setActiveExperiment(null)} 
            variant="outline"
            className="arabic-text"
          >
            العودة للتجارب
          </Button>
          <h3 className="text-xl font-bold arabic-text">{activeExperiment.title}</h3>
        </div>
        <ExperimentComponent />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-gray-800 mb-2 arabic-text">
          التجارب التفاعلية
        </h3>
        <p className="text-gray-600 arabic-text">
          اختر تجربة لتبدأ الاستكشاف العملي
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {currentExperiments.map((experiment) => {
          const IconComponent = experiment.icon
          return (
            <Card 
              key={experiment.id} 
              className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => setActiveExperiment(experiment)}
            >
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <IconComponent className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="arabic-text">{experiment.title}</CardTitle>
                <CardDescription className="arabic-text">
                  {experiment.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <Button className="w-full arabic-text">
                  <Play className="ml-2 h-4 w-4" />
                  ابدأ التجربة
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

// تجربة قانون أوم
const OhmLawExperiment = () => {
  const [voltage, setVoltage] = useState([12])
  const [resistance, setResistance] = useState([100])
  const [current, setCurrent] = useState(0)
  const [power, setPower] = useState(0)

  useEffect(() => {
    const V = voltage[0]
    const R = resistance[0]
    const I = V / R
    const P = V * I
    setCurrent(I)
    setPower(P)
  }, [voltage, resistance])

  const resetExperiment = () => {
    setVoltage([12])
    setResistance([100])
  }

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-center arabic-text">تجربة قانون أوم التفاعلية</CardTitle>
        <CardDescription className="text-center arabic-text">
          V = I × R | اكتشف العلاقة بين الجهد والتيار والمقاومة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-8">
        {/* Circuit Diagram */}
        <div className="bg-gray-50 p-8 rounded-lg">
          <div className="text-center mb-6">
            <h4 className="text-lg font-semibold arabic-text">مخطط الدائرة</h4>
          </div>
          <div className="flex items-center justify-center space-x-8 space-x-reverse">
            {/* Battery */}
            <div className="text-center">
              <div className="w-16 h-24 bg-red-500 rounded flex items-center justify-center text-white font-bold">
                {voltage[0]}V
              </div>
              <p className="mt-2 text-sm arabic-text">البطارية</p>
            </div>
            
            {/* Wire */}
            <div className="w-16 h-1 bg-gray-800"></div>
            
            {/* Resistor */}
            <div className="text-center">
              <div className="w-20 h-8 bg-yellow-500 rounded flex items-center justify-center text-black font-bold">
                {resistance[0]}Ω
              </div>
              <p className="mt-2 text-sm arabic-text">المقاومة</p>
            </div>
            
            {/* Wire */}
            <div className="w-16 h-1 bg-gray-800"></div>
            
            {/* Ammeter */}
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-xs">
                {current.toFixed(3)}A
              </div>
              <p className="mt-2 text-sm arabic-text">الأميتر</p>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <Label className="text-lg font-medium arabic-text">الجهد (فولت)</Label>
              <div className="mt-4">
                <Slider
                  value={voltage}
                  onValueChange={setVoltage}
                  max={24}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-600 mt-2">
                  <span>1V</span>
                  <span className="arabic-text">الجهد: {voltage[0]}V</span>
                  <span>24V</span>
                </div>
              </div>
            </div>

            <div>
              <Label className="text-lg font-medium arabic-text">المقاومة (أوم)</Label>
              <div className="mt-4">
                <Slider
                  value={resistance}
                  onValueChange={setResistance}
                  max={1000}
                  min={10}
                  step={10}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-600 mt-2">
                  <span>10Ω</span>
                  <span className="arabic-text">المقاومة: {resistance[0]}Ω</span>
                  <span>1000Ω</span>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-center arabic-text">النتائج</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="arabic-text">التيار:</span>
                  <Badge variant="secondary" className="text-lg">
                    {current.toFixed(3)} A
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="arabic-text">القدرة:</span>
                  <Badge variant="secondary" className="text-lg">
                    {power.toFixed(2)} W
                  </Badge>
                </div>
                <div className="text-center pt-4 border-t">
                  <p className="text-sm text-gray-600 arabic-text">
                    قانون أوم: V = I × R
                  </p>
                  <p className="text-lg font-mono">
                    {voltage[0]} = {current.toFixed(3)} × {resistance[0]}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Button onClick={resetExperiment} variant="outline" className="w-full arabic-text">
              <RotateCcw className="ml-2 h-4 w-4" />
              إعادة تعيين
            </Button>
          </div>
        </div>

        {/* Observations */}
        <Card className="bg-blue-50">
          <CardHeader>
            <CardTitle className="arabic-text">الملاحظات</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 arabic-text">
              <li>• عند زيادة الجهد، يزداد التيار بنفس النسبة (علاقة طردية)</li>
              <li>• عند زيادة المقاومة، يقل التيار (علاقة عكسية)</li>
              <li>• القدرة تزداد مع زيادة الجهد أو التيار</li>
              <li>• قانون أوم صالح للمقاومات الثابتة فقط</li>
            </ul>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  )
}

// تجربة قوانين كيرشوف
const KirchhoffExperiment = () => {
  const [voltage, setVoltage] = useState([12])
  const [r1, setR1] = useState([100])
  const [r2, setR2] = useState([200])
  const [r3, setR3] = useState([150])

  // حسابات الدائرة
  const totalResistance = r1[0] + ((r2[0] * r3[0]) / (r2[0] + r3[0]))
  const mainCurrent = voltage[0] / totalResistance
  const voltageR1 = mainCurrent * r1[0]
  const voltageParallel = voltage[0] - voltageR1
  const currentR2 = voltageParallel / r2[0]
  const currentR3 = voltageParallel / r3[0]

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-center arabic-text">تجربة قوانين كيرشوف</CardTitle>
        <CardDescription className="text-center arabic-text">
          تحليل الدوائر الكهربائية المعقدة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-8">
        {/* Circuit Diagram */}
        <div className="bg-gray-50 p-8 rounded-lg">
          <div className="text-center mb-6">
            <h4 className="text-lg font-semibold arabic-text">دائرة مختلطة (توالي وتوازي)</h4>
          </div>
          
          <div className="space-y-4">
            {/* Main current */}
            <div className="text-center">
              <Badge className="bg-red-500 text-white">
                التيار الرئيسي: {mainCurrent.toFixed(3)} A
              </Badge>
            </div>
            
            {/* Circuit representation */}
            <div className="grid grid-cols-3 gap-4 items-center">
              <div className="text-center">
                <div className="w-16 h-24 bg-red-500 rounded flex items-center justify-center text-white font-bold">
                  {voltage[0]}V
                </div>
                <p className="mt-2 text-sm arabic-text">المصدر</p>
              </div>
              
              <div className="text-center">
                <div className="w-20 h-8 bg-yellow-500 rounded flex items-center justify-center text-black font-bold">
                  R1: {r1[0]}Ω
                </div>
                <p className="mt-2 text-sm arabic-text">
                  V1: {voltageR1.toFixed(2)}V
                </p>
              </div>
              
              <div className="space-y-2">
                <div className="text-center">
                  <div className="w-20 h-8 bg-blue-500 rounded flex items-center justify-center text-white font-bold">
                    R2: {r2[0]}Ω
                  </div>
                  <p className="text-xs arabic-text">I2: {currentR2.toFixed(3)}A</p>
                </div>
                <div className="text-center">
                  <div className="w-20 h-8 bg-green-500 rounded flex items-center justify-center text-white font-bold">
                    R3: {r3[0]}Ω
                  </div>
                  <p className="text-xs arabic-text">I3: {currentR3.toFixed(3)}A</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <Label className="text-lg font-medium arabic-text">جهد المصدر (فولت)</Label>
              <Slider
                value={voltage}
                onValueChange={setVoltage}
                max={24}
                min={6}
                step={1}
                className="w-full mt-2"
              />
              <p className="text-center mt-2 arabic-text">{voltage[0]}V</p>
            </div>

            <div>
              <Label className="text-lg font-medium arabic-text">المقاومة R1 (أوم)</Label>
              <Slider
                value={r1}
                onValueChange={setR1}
                max={500}
                min={50}
                step={10}
                className="w-full mt-2"
              />
              <p className="text-center mt-2 arabic-text">{r1[0]}Ω</p>
            </div>

            <div>
              <Label className="text-lg font-medium arabic-text">المقاومة R2 (أوم)</Label>
              <Slider
                value={r2}
                onValueChange={setR2}
                max={500}
                min={50}
                step={10}
                className="w-full mt-2"
              />
              <p className="text-center mt-2 arabic-text">{r2[0]}Ω</p>
            </div>

            <div>
              <Label className="text-lg font-medium arabic-text">المقاومة R3 (أوم)</Label>
              <Slider
                value={r3}
                onValueChange={setR3}
                max={500}
                min={50}
                step={10}
                className="w-full mt-2"
              />
              <p className="text-center mt-2 arabic-text">{r3[0]}Ω</p>
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-center arabic-text">قانون كيرشوف الأول</CardTitle>
                <CardDescription className="text-center arabic-text">
                  مجموع التيارات الداخلة = مجموع التيارات الخارجة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="arabic-text mb-2">عند العقدة:</p>
                  <p className="font-mono text-lg">
                    I₁ = I₂ + I₃
                  </p>
                  <p className="font-mono">
                    {mainCurrent.toFixed(3)} = {currentR2.toFixed(3)} + {currentR3.toFixed(3)}
                  </p>
                  <p className="font-mono">
                    {mainCurrent.toFixed(3)} ≈ {(currentR2 + currentR3).toFixed(3)}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-center arabic-text">قانون كيرشوف الثاني</CardTitle>
                <CardDescription className="text-center arabic-text">
                  مجموع الجهود في أي مسار مغلق = صفر
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="arabic-text mb-2">في المسار الرئيسي:</p>
                  <p className="font-mono text-lg">
                    V - V₁ - V₂₃ = 0
                  </p>
                  <p className="font-mono">
                    {voltage[0]} - {voltageR1.toFixed(2)} - {voltageParallel.toFixed(2)} = 0
                  </p>
                  <p className="font-mono">
                    {(voltage[0] - voltageR1 - voltageParallel).toFixed(2)} ≈ 0
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-green-50">
              <CardHeader>
                <CardTitle className="text-center arabic-text">النتائج</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span className="arabic-text">المقاومة الكلية:</span>
                  <span>{totalResistance.toFixed(2)} Ω</span>
                </div>
                <div className="flex justify-between">
                  <span className="arabic-text">التيار الرئيسي:</span>
                  <span>{mainCurrent.toFixed(3)} A</span>
                </div>
                <div className="flex justify-between">
                  <span className="arabic-text">القدرة الكلية:</span>
                  <span>{(voltage[0] * mainCurrent).toFixed(2)} W</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// تجارب أخرى (مبسطة)
const GravityExperiment = () => (
  <Card>
    <CardHeader>
      <CardTitle className="arabic-text">تجربة السقوط الحر</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="arabic-text">هذه التجربة قيد التطوير...</p>
    </CardContent>
  </Card>
)

const MeasurementExperiment = () => (
  <Card>
    <CardHeader>
      <CardTitle className="arabic-text">تجربة القياس والوحدات</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="arabic-text">هذه التجربة قيد التطوير...</p>
    </CardContent>
  </Card>
)

const ForcesExperiment = () => (
  <Card>
    <CardHeader>
      <CardTitle className="arabic-text">تجربة القوى والحركة</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="arabic-text">هذه التجربة قيد التطوير...</p>
    </CardContent>
  </Card>
)

const EnergyExperiment = () => (
  <Card>
    <CardHeader>
      <CardTitle className="arabic-text">تجربة الطاقة والشغل</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="arabic-text">هذه التجربة قيد التطوير...</p>
    </CardContent>
  </Card>
)

const RelativityExperiment = () => (
  <Card>
    <CardHeader>
      <CardTitle className="arabic-text">محاكاة النسبية الخاصة</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="arabic-text">هذه التجربة قيد التطوير...</p>
    </CardContent>
  </Card>
)

const QuantumExperiment = () => (
  <Card>
    <CardHeader>
      <CardTitle className="arabic-text">محاكاة الظواهر الكمية</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="arabic-text">هذه التجربة قيد التطوير...</p>
    </CardContent>
  </Card>
)

export default ExperimentComponent

