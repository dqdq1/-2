import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Crown, Star, Users, Clock, Target, Zap } from 'lucide-react';

const CompetitionSystem = ({ level = 'beginner' }) => {
  const [activeCompetition, setActiveCompetition] = useState(null);
  const [userScore, setUserScore] = useState(0);
  const [leaderboard, setLeaderboard] = useState([]);
  const [timeLeft, setTimeLeft] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [competitionStarted, setCompetitionStarted] = useState(false);
  const [showResults, setShowResults] = useState(false);

  // بيانات المسابقات
  const competitions = {
    beginner: {
      id: 1,
      title: "مسابقة أساسيات الفيزياء",
      description: "تحدى معرفتك في المفاهيم الأساسية للفيزياء",
      duration: 600, // 10 دقائق
      totalQuestions: 15,
      prize: "شهادة إنجاز + 100 نقطة",
      difficulty: "مبتدئ",
      participants: 1247,
      questions: [
        {
          id: 1,
          question: "ما هي وحدة قياس القوة في النظام الدولي؟",
          options: ["نيوتن", "جول", "واط", "باسكال"],
          correct: 0,
          points: 10,
          timeLimit: 30
        },
        {
          id: 2,
          question: "أي من القوانين التالية يصف العلاقة بين القوة والكتلة والتسارع؟",
          options: ["قانون نيوتن الأول", "قانون نيوتن الثاني", "قانون نيوتن الثالث", "قانون الجاذبية"],
          correct: 1,
          points: 10,
          timeLimit: 30
        },
        {
          id: 3,
          question: "ما هي سرعة الضوء في الفراغ تقريباً؟",
          options: ["3 × 10⁶ م/ث", "3 × 10⁸ م/ث", "3 × 10¹⁰ م/ث", "3 × 10⁴ م/ث"],
          correct: 1,
          points: 15,
          timeLimit: 45
        },
        {
          id: 4,
          question: "في دائرة كهربائية بسيطة، إذا كان الجهد 12 فولت والمقاومة 4 أوم، فما هو التيار؟",
          options: ["2 أمبير", "3 أمبير", "4 أمبير", "6 أمبير"],
          correct: 1,
          points: 20,
          timeLimit: 60
        },
        {
          id: 5,
          question: "أي من التالي يمثل طاقة حركية؟",
          options: ["mgh", "½mv²", "kx²", "qV"],
          correct: 1,
          points: 15,
          timeLimit: 45
        }
      ]
    },
    intermediate: {
      id: 2,
      title: "تحدي الفيزياء المتوسط",
      description: "اختبر مهاراتك في المفاهيم المتقدمة",
      duration: 900, // 15 دقيقة
      totalQuestions: 20,
      prize: "شهادة تميز + 200 نقطة",
      difficulty: "متوسط",
      participants: 856,
      questions: [
        {
          id: 1,
          question: "في قانون كيرشوف للتيار، مجموع التيارات الداخلة إلى عقدة يساوي:",
          options: ["صفر", "مجموع التيارات الخارجة", "ضعف التيار الرئيسي", "نصف التيار الرئيسي"],
          correct: 1,
          points: 15,
          timeLimit: 45
        },
        {
          id: 2,
          question: "ما هو معامل الانكسار للماء تقريباً؟",
          options: ["1.0", "1.33", "1.5", "2.0"],
          correct: 1,
          points: 20,
          timeLimit: 60
        }
      ]
    },
    advanced: {
      id: 3,
      title: "بطولة الفيزياء المتقدمة",
      description: "للخبراء والمتخصصين في الفيزياء",
      duration: 1200, // 20 دقيقة
      totalQuestions: 25,
      prize: "شهادة خبير + 500 نقطة",
      difficulty: "متقدم",
      participants: 324,
      questions: [
        {
          id: 1,
          question: "في النسبية الخاصة، ما هي معادلة تحويل الطاقة والكتلة؟",
          options: ["E = mc", "E = mc²", "E = m²c", "E = mc³"],
          correct: 1,
          points: 25,
          timeLimit: 90
        }
      ]
    }
  };

  // بيانات لوحة الصدارة (محاكاة)
  const mockLeaderboard = [
    { rank: 1, name: "أحمد محمد", score: 285, level: "متقدم", avatar: "👨‍🎓" },
    { rank: 2, name: "فاطمة علي", score: 270, level: "متقدم", avatar: "👩‍🎓" },
    { rank: 3, name: "محمد حسن", score: 255, level: "متوسط", avatar: "👨‍💻" },
    { rank: 4, name: "زينب أحمد", score: 240, level: "متوسط", avatar: "👩‍💻" },
    { rank: 5, name: "علي محمود", score: 225, level: "مبتدئ", avatar: "👨‍🔬" },
    { rank: 6, name: "مريم سالم", score: 210, level: "مبتدئ", avatar: "👩‍🔬" },
    { rank: 7, name: "يوسف كريم", score: 195, level: "مبتدئ", avatar: "👨‍🎓" },
    { rank: 8, name: "نور الهدى", score: 180, level: "مبتدئ", avatar: "👩‍🎓" }
  ];

  useEffect(() => {
    setActiveCompetition(competitions[level]);
    setLeaderboard(mockLeaderboard);
  }, [level]);

  useEffect(() => {
    if (timeLeft > 0 && competitionStarted && !showResults) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && competitionStarted) {
      endCompetition();
    }
  }, [timeLeft, competitionStarted, showResults]);

  const startCompetition = () => {
    setCompetitionStarted(true);
    setTimeLeft(activeCompetition.duration);
    setCurrentQuestion(0);
    setUserScore(0);
    setShowResults(false);
  };

  const handleAnswerSelect = (answerIndex) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    const currentQ = activeCompetition.questions[currentQuestion];
    if (selectedAnswer === currentQ.correct) {
      setUserScore(userScore + currentQ.points);
    }

    if (currentQuestion < activeCompetition.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      endCompetition();
    }
  };

  const endCompetition = () => {
    setCompetitionStarted(false);
    setShowResults(true);
  };

  const resetCompetition = () => {
    setCompetitionStarted(false);
    setShowResults(false);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setUserScore(0);
    setTimeLeft(null);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1: return <Crown className="w-6 h-6 text-yellow-500" />;
      case 2: return <Medal className="w-6 h-6 text-gray-400" />;
      case 3: return <Medal className="w-6 h-6 text-amber-600" />;
      default: return <Star className="w-5 h-5 text-gray-400" />;
    }
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'مبتدئ': return 'bg-green-500';
      case 'متوسط': return 'bg-yellow-500';
      case 'متقدم': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  if (!activeCompetition) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="p-8 text-center">
          <Trophy className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-xl font-bold mb-2">لا توجد مسابقات متاحة</h3>
          <p className="text-gray-600">سيتم إضافة المزيد من المسابقات قريباً</p>
        </CardContent>
      </Card>
    );
  }

  if (showResults) {
    const maxScore = activeCompetition.questions.reduce((sum, q) => sum + q.points, 0);
    const percentage = Math.round((userScore / maxScore) * 100);
    const userRank = Math.floor(Math.random() * 50) + 1; // محاكاة ترتيب المستخدم

    return (
      <div className="w-full max-w-6xl mx-auto space-y-6">
        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Trophy className="w-20 h-20 text-yellow-500" />
            </div>
            <CardTitle className="text-3xl">نتائج المسابقة</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="text-5xl font-bold text-blue-600 mb-2">{userScore}</div>
              <div className="text-xl text-gray-600 mb-4">من أصل {maxScore} نقطة</div>
              <div className="text-2xl font-bold text-green-600 mb-4">{percentage}%</div>
              <Badge className="bg-blue-500 text-white px-6 py-2 text-lg">
                المركز #{userRank}
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-blue-50 rounded-lg">
                <Zap className="w-8 h-8 mx-auto mb-2 text-blue-500" />
                <div className="text-lg font-bold">النقاط المكتسبة</div>
                <div className="text-2xl font-bold text-blue-600">{userScore}</div>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <Target className="w-8 h-8 mx-auto mb-2 text-green-500" />
                <div className="text-lg font-bold">الدقة</div>
                <div className="text-2xl font-bold text-green-600">{percentage}%</div>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <Users className="w-8 h-8 mx-auto mb-2 text-purple-500" />
                <div className="text-lg font-bold">الترتيب</div>
                <div className="text-2xl font-bold text-purple-600">#{userRank}</div>
              </div>
            </div>

            <div className="flex gap-4 justify-center">
              <Button onClick={resetCompetition} variant="outline">
                إعادة المسابقة
              </Button>
              <Button onClick={() => window.location.reload()}>
                العودة للدروس
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* لوحة الصدارة */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-6 h-6 text-yellow-500" />
              لوحة الصدارة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {leaderboard.slice(0, 10).map((player) => (
                <div key={player.rank} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    {getRankIcon(player.rank)}
                    <span className="font-bold text-lg">#{player.rank}</span>
                  </div>
                  <div className="text-2xl">{player.avatar}</div>
                  <div className="flex-1">
                    <div className="font-bold">{player.name}</div>
                    <Badge className={`${getDifficultyColor(player.level)} text-white text-xs`}>
                      {player.level}
                    </Badge>
                  </div>
                  <div className="text-xl font-bold text-blue-600">{player.score}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!competitionStarted) {
    return (
      <div className="w-full max-w-6xl mx-auto space-y-6">
        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Trophy className="w-20 h-20 text-yellow-500" />
            </div>
            <CardTitle className="text-3xl">{activeCompetition.title}</CardTitle>
            <p className="text-gray-600 text-lg">{activeCompetition.description}</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
              <div className="p-4 bg-blue-50 rounded-lg">
                <Clock className="w-8 h-8 mx-auto mb-2 text-blue-500" />
                <div className="text-lg font-bold">المدة</div>
                <div className="text-xl font-bold text-blue-600">{formatTime(activeCompetition.duration)}</div>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <Target className="w-8 h-8 mx-auto mb-2 text-green-500" />
                <div className="text-lg font-bold">الأسئلة</div>
                <div className="text-xl font-bold text-green-600">{activeCompetition.totalQuestions}</div>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <Users className="w-8 h-8 mx-auto mb-2 text-purple-500" />
                <div className="text-lg font-bold">المشاركون</div>
                <div className="text-xl font-bold text-purple-600">{activeCompetition.participants.toLocaleString()}</div>
              </div>
              <div className="p-4 bg-yellow-50 rounded-lg">
                <Star className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
                <div className="text-lg font-bold">الجائزة</div>
                <div className="text-sm font-bold text-yellow-600">{activeCompetition.prize}</div>
              </div>
            </div>

            <div className="text-center">
              <Badge className={`${getDifficultyColor(activeCompetition.difficulty)} text-white px-4 py-2 text-lg mb-4`}>
                مستوى {activeCompetition.difficulty}
              </Badge>
              <div className="space-y-2 max-w-md mx-auto">
                <h3 className="text-lg font-bold">قواعد المسابقة:</h3>
                <ul className="text-right space-y-1 text-sm">
                  <li>• وقت محدد لكل سؤال</li>
                  <li>• نقاط مختلفة حسب صعوبة السؤال</li>
                  <li>• ترتيب فوري في لوحة الصدارة</li>
                  <li>• جوائز للمتفوقين</li>
                </ul>
              </div>
            </div>

            <div className="text-center">
              <Button onClick={startCompetition} size="lg" className="px-8 py-3 text-lg">
                <Trophy className="w-5 h-5 mr-2" />
                بدء المسابقة
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* لوحة الصدارة */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-6 h-6 text-yellow-500" />
              لوحة الصدارة الحالية
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {leaderboard.slice(0, 5).map((player) => (
                <div key={player.rank} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    {getRankIcon(player.rank)}
                    <span className="font-bold text-lg">#{player.rank}</span>
                  </div>
                  <div className="text-2xl">{player.avatar}</div>
                  <div className="flex-1">
                    <div className="font-bold">{player.name}</div>
                    <Badge className={`${getDifficultyColor(player.level)} text-white text-xs`}>
                      {player.level}
                    </Badge>
                  </div>
                  <div className="text-xl font-bold text-blue-600">{player.score}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentQ = activeCompetition.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / activeCompetition.questions.length) * 100;

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-red-500" />
              <span className="font-mono text-xl text-red-600">{formatTime(timeLeft)}</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-blue-500" />
              <span className="font-bold text-blue-600">{userScore} نقطة</span>
            </div>
          </div>
          <div className="text-sm text-gray-600">
            السؤال {currentQuestion + 1} من {activeCompetition.questions.length}
          </div>
        </div>
        <Progress value={progress} className="w-full" />
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <Badge className="bg-purple-500 text-white px-3 py-1 mb-4">
            {currentQ.points} نقطة
          </Badge>
          <h3 className="text-xl font-bold mb-6">{currentQ.question}</h3>
        </div>

        <div className="space-y-3">
          {currentQ.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerSelect(index)}
              className={`w-full p-4 text-right rounded-lg border-2 transition-all ${
                selectedAnswer === index
                  ? 'border-blue-500 bg-blue-50 shadow-md'
                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  selectedAnswer === index ? 'border-blue-500 bg-blue-500' : 'border-gray-300'
                }`}>
                  {selectedAnswer === index && (
                    <div className="w-3 h-3 rounded-full bg-white"></div>
                  )}
                </div>
                <span className="text-lg">{option}</span>
              </div>
            </button>
          ))}
        </div>

        <div className="flex justify-center">
          <Button
            onClick={handleNextQuestion}
            disabled={selectedAnswer === null}
            size="lg"
            className="px-8"
          >
            {currentQuestion === activeCompetition.questions.length - 1 ? 'إنهاء المسابقة' : 'السؤال التالي'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CompetitionSystem;

