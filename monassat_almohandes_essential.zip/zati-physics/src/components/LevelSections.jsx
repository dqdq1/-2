import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { BookOpen, Users, Award, Zap, ArrowLeft, Target, Trophy, FlaskConical } from 'lucide-react'
import QuizComponent from './QuizComponent'
import { beginnerQuizzes } from '../data/beginner_quizzes'
import { intermediateQuizzes } from '../data/intermediate_quizzes'
import { advancedQuizzes } from '../data/advanced_quizzes'

const LevelSections = ({ onStartLearning }) => {
  const [selectedLevel, setSelectedLevel] = useState(null)
  const [activeTab, setActiveTab] = useState('explanations')

  const levels = [
    {
      id: 'beginner',
      title: 'مستوى المبتدئين',
      description: 'ابدأ رحلتك في عالم الفيزياء من الأساسيات',
      icon: BookOpen,
      color: 'bg-green-500',
      progress: 85,
      lessons: 25,
      topics: [
        'ما هي الفيزياء؟',
        'الوحدات والقياسات',
        'أساسيات الميكانيكا',
        'مقدمة في الطاقة',
        'مقدمة في الكهرباء'
      ],
      difficulty: 'سهل',
      audience: 'للمبتدئين تماماً'
    },
    {
      id: 'intermediate',
      title: 'مستوى المتوسطين',
      description: 'تعمق في المفاهيم وحل المسائل المتقدمة',
      icon: Users,
      color: 'bg-blue-500',
      progress: 60,
      lessons: 35,
      topics: [
        'الميكانيكا الكلاسيكية المتقدمة',
        'الكهرومغناطيسية المتقدمة',
        'الديناميكا الحرارية',
        'الموجات والصوت',
        'البصريات'
      ],
      difficulty: 'متوسط',
      audience: 'لمن لديه أساسيات الفيزياء'
    },
    {
      id: 'advanced',
      title: 'مستوى المحترفين',
      description: 'استكشف أحدث النظريات والأبحاث في الفيزياء',
      icon: Award,
      color: 'bg-purple-500',
      progress: 30,
      lessons: 45,
      topics: [
        'النسبية العامة',
        'ميكانيكا الكم',
        'فيزياء الجسيمات',
        'فيزياء الفلك',
        'الفيزياء النظرية'
      ],
      difficulty: 'صعب',
      audience: 'للمتخصصين والباحثين'
    }
  ]

  const QuizSection = ({ level }) => {
    const quizData = {
      beginner: beginnerQuizzes,
      intermediate: intermediateQuizzes,
      advanced: advancedQuizzes
    }

    const currentQuizzes = quizData[level] || []

    if (currentQuizzes.length === 0) {
      return (
        <div className="text-center py-8">
          <Target className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-xl font-bold mb-2">لا توجد اختبارات متاحة</h3>
          <p className="text-gray-600">سيتم إضافة المزيد من الاختبارات قريباً</p>
        </div>
      )
    }

    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold mb-4">اختبارات {levels.find(l => l.id === level)?.title}</h3>
        <div className="grid gap-4">
          {currentQuizzes.slice(0, 5).map((quiz, index) => (
            <Card key={quiz.id} className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">{quiz.question}</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    {quiz.options.length} خيارات متاحة
                  </p>
                </div>
                <Button size="sm">
                  ابدأ الاختبار
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  const CompetitionSection = () => (
    <div className="text-center py-8">
      <Trophy className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
      <h3 className="text-xl font-bold mb-2">مسابقات تفاعلية</h3>
      <p className="text-gray-600 mb-4">تحدى نفسك وتنافس مع الآخرين</p>
      <Button>ابدأ المسابقة</Button>
    </div>
  )

  const ExperimentSection = () => (
    <div className="text-center py-8">
      <FlaskConical className="w-16 h-16 mx-auto mb-4 text-blue-500" />
      <h3 className="text-xl font-bold mb-2">تجارب تفاعلية</h3>
      <p className="text-gray-600 mb-4">اكتشف القوانين الفيزيائية من خلال التجارب</p>
      <Button>ابدأ التجربة</Button>
    </div>
  )

  if (selectedLevel) {
    const level = levels.find(l => l.id === selectedLevel)
    const IconComponent = level.icon

    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button 
            variant="outline" 
            onClick={() => setSelectedLevel(null)}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة للمستويات
          </Button>
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-full ${level.color} text-white`}>
              <IconComponent className="w-6 h-6" />
            </div>
            <h2 className="text-2xl font-bold">{level.title}</h2>
          </div>
        </div>

        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === 'explanations' ? 'default' : 'outline'}
            onClick={() => setActiveTab('explanations')}
            className="flex items-center gap-2"
          >
            📚 الشروحات
          </Button>
          <Button
            variant={activeTab === 'quizzes' ? 'default' : 'outline'}
            onClick={() => setActiveTab('quizzes')}
            className="flex items-center gap-2"
          >
            📝 الاختبارات
          </Button>
          <Button
            variant={activeTab === 'competitions' ? 'default' : 'outline'}
            onClick={() => setActiveTab('competitions')}
            className="flex items-center gap-2"
          >
            🏆 المسابقات
          </Button>
          <Button
            variant={activeTab === 'experiments' ? 'default' : 'outline'}
            onClick={() => setActiveTab('experiments')}
            className="flex items-center gap-2"
          >
            🔬 التجارب
          </Button>
        </div>

        <div className="min-h-[400px]">
          {activeTab === 'explanations' && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold mb-4">شروحات {level.title}</h3>
              <div className="grid gap-4">
                {level.topics.map((topic, index) => (
                  <Card key={index} className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">{topic}</h4>
                        <p className="text-sm text-gray-600 mt-1">
                          شرح مفصل مع أمثلة عملية
                        </p>
                      </div>
                      <Button size="sm">
                        ابدأ الدرس
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
          
          {activeTab === 'quizzes' && <QuizSection level={selectedLevel} />}
          {activeTab === 'competitions' && <CompetitionSection />}
          {activeTab === 'experiments' && <ExperimentSection />}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-4">اختر مستواك</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          ابدأ من المستوى المناسب لك وتقدم في رحلة تعلم الفيزياء خطوة بخطوة
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {levels.map((level) => {
          const IconComponent = level.icon
          return (
            <Card key={level.id} className="relative overflow-hidden">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-full ${level.color} text-white`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-600">التقدم</div>
                    <div className="text-lg font-bold">{level.progress}%</div>
                  </div>
                </div>
                <CardTitle className="text-xl">{level.title}</CardTitle>
                <CardDescription className="text-gray-600">
                  {level.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Progress value={level.progress} className="h-2" />
                
                <div className="flex justify-between text-sm">
                  <div className="text-center">
                    <div className="font-bold text-lg text-green-600">{level.lessons}</div>
                    <div className="text-gray-600">درس</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-lg text-blue-600">{level.difficulty}</div>
                    <div className="text-gray-600">المستوى</div>
                  </div>
                </div>

                <div className="text-sm text-gray-600 text-center">
                  {level.audience}
                </div>

                <div>
                  <h4 className="font-medium mb-2">المواضيع الرئيسية:</h4>
                  <ul className="text-sm space-y-1">
                    {level.topics.map((topic, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <span className="text-yellow-500">⚡</span>
                        {topic}
                      </li>
                    ))}
                  </ul>
                </div>

                <Button 
                  className="w-full" 
                  onClick={() => setSelectedLevel(level.id)}
                >
                  ابدأ التعلم
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="text-center">
        <div className="bg-blue-50 p-6 rounded-lg">
          <h3 className="text-lg font-bold mb-2">غير متأكد من مستواك؟</h3>
          <p className="text-gray-600 mb-4">
            خذ اختبار تحديد المستوى المجاني لنساعدك في اختيار المسار المناسب
          </p>
          <Button variant="outline">
            <Target className="w-4 h-4 mr-2" />
            اختبار تحديد المستوى
          </Button>
        </div>
      </div>
    </div>
  )
}

export default LevelSections

