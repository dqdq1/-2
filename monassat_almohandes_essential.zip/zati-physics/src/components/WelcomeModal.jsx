import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Facebook, Mail, BookOpen } from 'lucide-react'

const WelcomeModal = ({ onLogin }) => {
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    // التحقق من حالة التسجيل المحفوظة
    const hasLoggedIn = localStorage.getItem('zahraa_physics_logged_in')
    
    if (!hasLoggedIn) {
      // عرض النافذة فوراً إذا لم يسجل المستخدم من قبل
      setIsOpen(true)
    } else {
      // إذا سجل من قبل، تفعيل الوصول مباشرة
      onLogin(true)
    }
  }, [onLogin])

  const handleSocialLogin = (provider) => {
    setIsLoading(true)
    
    // محاكاة عملية تسجيل الدخول
    setTimeout(() => {
      setIsLoading(false)
      
      // حفظ حالة التسجيل في localStorage
      localStorage.setItem('zahraa_physics_logged_in', 'true')
      localStorage.setItem('zahraa_physics_login_provider', provider)
      localStorage.setItem('zahraa_physics_login_date', new Date().toISOString())
      
      // إغلاق النافذة وتفعيل الوصول
      setIsOpen(false)
      onLogin(true)
      
      // رسالة ترحيب
      setTimeout(() => {
        alert(`مرحباً بك في Zahraa Physics! تم تسجيل الدخول بنجاح عبر ${provider}`)
      }, 500)
    }, 2000)
  }

  // منع إغلاق النافذة - التسجيل إلزامي
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <BookOpen className="h-12 w-12 text-blue-600" />
          </div>
          <CardTitle className="text-3xl arabic-text text-blue-800">
            مرحباً بك في Zahraa Physics
          </CardTitle>
          <CardDescription className="arabic-text text-lg">
            منصتك المتخصصة لتعلم الفيزياء من الصفر إلى الاحتراف
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="text-center">
            <p className="text-gray-700 arabic-text mb-4 font-medium">
              للحصول على تجربة تعليمية كاملة وحفظ تقدمك، يرجى تسجيل الدخول
            </p>
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
              <p className="text-yellow-800 arabic-text text-sm font-medium">
                ⚠️ تسجيل الدخول مطلوب للوصول إلى المحتوى التعليمي
              </p>
            </div>
          </div>

          {/* Facebook Login */}
          <Button
            onClick={() => handleSocialLogin('Facebook')}
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white arabic-text"
            size="lg"
          >
            <Facebook className="ml-2 h-5 w-5" />
            {isLoading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول عبر فيسبوك'}
          </Button>

          {/* Google Login */}
          <Button
            onClick={() => handleSocialLogin('Google')}
            disabled={isLoading}
            variant="outline"
            className="w-full arabic-text border-2 hover:bg-gray-50"
            size="lg"
          >
            <Mail className="ml-2 h-5 w-5" />
            {isLoading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول عبر جوجل'}
          </Button>

          {/* Benefits */}
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <h4 className="font-semibold text-blue-800 mb-3 arabic-text">مميزات التسجيل:</h4>
            <ul className="text-sm text-blue-700 space-y-2 arabic-text">
              <li className="flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full ml-2"></span>
                حفظ تقدمك في الدروس
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full ml-2"></span>
                الوصول إلى جميع المستويات
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full ml-2"></span>
                اختبارات تقييمية شخصية
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full ml-2"></span>
                شهادات إنجاز
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <h4 className="font-semibold text-green-800 mb-2 arabic-text">للمساعدة والدعم:</h4>
            <p className="text-sm text-green-700 arabic-text">
              📞 رقم الهاتف: 07739400501
            </p>
            <p className="text-sm text-green-700 arabic-text">
              📧 تواصل معنا عبر فيسبوك: Zahraa Physics
            </p>
          </div>

          {/* Terms */}
          <p className="text-xs text-gray-500 text-center arabic-text">
            بتسجيل الدخول، أنت توافق على{' '}
            <a href="#" className="text-blue-600 hover:underline">
              شروط الاستخدام
            </a>{' '}
            و{' '}
            <a href="#" className="text-blue-600 hover:underline">
              سياسة الخصوصية
            </a>
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

export default WelcomeModal


