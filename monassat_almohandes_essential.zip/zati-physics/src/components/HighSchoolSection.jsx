import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { BookOpen, FileText, CheckCircle, Star } from 'lucide-react'
import { useState } from 'react'

const HighSchoolSection = ({ onNavigate }) => {
  const [selectedChapter, setSelectedChapter] = useState(null)

  const chapters = [
    { id: 1, title: "المتسعات", description: "سعة المتسعة والعازل الكهربائي وربط المتسعات", difficulty: "متوسط" },
    { id: 2, title: "الحث الكهرومغناطيسي", description: "قانون فاراداي وقانون لنز والقوة الدافعة الحركية", difficulty: "صعب" },
    { id: 3, title: "التيار المتناوب", description: "دوائر AC والممانعة والرنين وعامل القدرة", difficulty: "صعب" },
    { id: 4, title: "الموجات الكهرومغناطيسية", description: "نظرية ماكسويل وتجربة هيرتز ومبادئ الإرسال", difficulty: "متوسط" },
    { id: 5, title: "البصريات الفيزيائية", description: "التداخل والحيود والاستقطاب وتجربة يونغ", difficulty: "صعب" },
    { id: 6, title: "الفيزياء الحديثة", description: "إشعاع الجسم الأسود والظاهرة الكهروضوئية وموجات دي برولي", difficulty: "صعب" }
  ]

  const getDifficultyColor = (difficulty) => {
    switch(difficulty) {
      case 'سهل': return 'text-green-600 bg-green-100'
      case 'متوسط': return 'text-yellow-600 bg-yellow-100'
      case 'صعب': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  const handleChapterClick = (chapter) => {
    setSelectedChapter(chapter)
  }

  const handleBackToChapters = () => {
    setSelectedChapter(null)
  }

  if (selectedChapter) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-6">
        <div className="max-w-4xl mx-auto">
          <Button 
            onClick={handleBackToChapters}
            className="mb-6 bg-purple-600 hover:bg-purple-700"
          >
            ← العودة للفصول
          </Button>
          
          <Card className="mb-6">
            <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
              <CardTitle className="text-2xl text-right">
                الفصل {selectedChapter.id}: {selectedChapter.title}
              </CardTitle>
              <div className="flex justify-end">
                <span className={`px-3 py-1 rounded-full text-sm ${getDifficultyColor(selectedChapter.difficulty)}`}>
                  {selectedChapter.difficulty}
                </span>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-2 border-purple-200 hover:border-purple-400 transition-colors">
                  <CardHeader className="bg-purple-50">
                    <CardTitle className="flex items-center gap-2 text-purple-700 text-right">
                      <BookOpen className="w-5 h-5" />
                      الشروحات المختصرة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <p className="text-gray-600 text-right mb-4">
                      شروحات متقدمة للمفاهيم الفيزيائية المعقدة
                    </p>
                    <Button 
                      className="w-full bg-purple-600 hover:bg-purple-700"
                      onClick={() => window.open(`/content/high_school_physics/chapter${selectedChapter.id}_explanation.md`, '_blank')}
                    >
                      عرض الشروحات
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-2 border-pink-200 hover:border-pink-400 transition-colors">
                  <CardHeader className="bg-pink-50">
                    <CardTitle className="flex items-center gap-2 text-pink-700 text-right">
                      <FileText className="w-5 h-5" />
                      حلول أسئلة الفصل
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <p className="text-gray-600 text-right mb-4">
                      حلول تفصيلية مع الاشتقاقات الرياضية
                    </p>
                    <Button 
                      className="w-full bg-pink-600 hover:bg-pink-700"
                      onClick={() => window.open(`/content/high_school_physics/chapter${selectedChapter.id}_explanation.md`, '_blank')}
                    >
                      عرض الحلول
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h3 className="text-lg font-semibold text-blue-800 text-right mb-2">
                  🎯 استراتيجيات الدراسة للسادس الإعدادي
                </h3>
                <ul className="text-blue-700 text-right space-y-1">
                  <li>• ركز على فهم المفاهيم الأساسية قبل حفظ القوانين</li>
                  <li>• تدرب على حل المسائل الرياضية بانتظام</li>
                  <li>• اربط النظريات بالتطبيقات العملية</li>
                  <li>• راجع الاشتقاقات الرياضية للقوانين</li>
                  <li>• حل أسئلة الامتحانات الوزارية السابقة</li>
                </ul>
              </div>

              {selectedChapter.difficulty === 'صعب' && (
                <div className="mt-4 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                  <h3 className="text-lg font-semibold text-orange-800 text-right mb-2">
                    ⚠️ تنبيه: فصل متقدم
                  </h3>
                  <p className="text-orange-700 text-right">
                    هذا الفصل يتطلب فهماً عميقاً للرياضيات والفيزياء. خذ وقتك في الدراسة ولا تتردد في مراجعة المفاهيم الأساسية.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            فيزياء السادس الإعدادي
          </h1>
          <p className="text-xl text-gray-600">
            شروحات متقدمة وحلول أسئلة الفصل
          </p>
          <div className="flex items-center justify-center gap-2 mt-2">
            <Star className="w-5 h-5 text-yellow-500 fill-current" />
            <span className="text-sm text-gray-600">مستوى متقدم</span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {chapters.map((chapter) => (
            <Card 
              key={chapter.id}
              className="hover:shadow-lg transition-shadow cursor-pointer border-2 border-purple-200 hover:border-purple-400"
              onClick={() => handleChapterClick(chapter)}
            >
              <CardHeader className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                <div className="flex justify-between items-start">
                  <span className={`px-2 py-1 rounded-full text-xs ${getDifficultyColor(chapter.difficulty)}`}>
                    {chapter.difficulty}
                  </span>
                  <div className="text-right">
                    <CardTitle>الفصل {chapter.id}</CardTitle>
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-right">
                  {chapter.title}
                </h3>
              </CardHeader>
              <CardContent className="p-4">
                <p className="text-gray-600 text-right mb-4">
                  {chapter.description}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span className="text-sm">متوفر</span>
                  </div>
                  <Button 
                    size="sm" 
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    ادخل للفصل
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Button 
            onClick={() => onNavigate('home')}
            variant="outline"
            className="border-purple-600 text-purple-600 hover:bg-purple-50"
          >
            العودة للصفحة الرئيسية
          </Button>
        </div>
      </div>
    </div>
  )
}

export default HighSchoolSection

