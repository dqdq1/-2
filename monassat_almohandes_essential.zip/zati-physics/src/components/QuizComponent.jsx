import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { CheckCircle, XCircle, RotateCcw, Trophy, BookOpen } from 'lucide-react'
import { beginnerQuizzes } from '../data/beginner_quizzes'
import { intermediateQuizzes } from '../data/intermediate_quizzes'
import { advancedQuizzes } from '../data/advanced_quizzes'

const QuizComponent = ({ level, lessonId }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState({})
  const [showResults, setShowResults] = useState(false)
  const [score, setScore] = useState(0)

  // دمج البيانات من ملفات الاختبارات الجديدة
  const allQuizzes = {
    beginner: beginnerQuizzes,
    intermediate: intermediateQuizzes,
    advanced: advancedQuizzes
  }

  const quizData = {
    beginner: {
      1: {
        title: 'اختبار: ما هي الفيزياء؟',
        questions: allQuizzes.beginner.slice(0, 5) // أول 5 أسئلة
      },
      2: {
        title: 'اختبار: الوحدات والقياسات',
        questions: allQuizzes.beginner.slice(5, 10) // الأسئلة من 6 إلى 10
      }
    },
    intermediate: {
      1: {
        title: 'اختبار: الميكانيكا الكلاسيكية المتقدمة',
        questions: allQuizzes.intermediate.slice(0, 5) // أول 5 أسئلة
      },
      2: {
        title: 'اختبار: الكهرومغناطيسية المتقدمة',
        questions: allQuizzes.intermediate.slice(5, 10) // الأسئلة من 6 إلى 10
      }
    },
    advanced: {
      1: {
        title: 'اختبار: النسبية الخاصة',
        questions: allQuizzes.advanced.slice(0, 5) // أول 5 أسئلة
      },
      2: {
        title: 'اختبار: الفيزياء الحديثة',
        questions: allQuizzes.advanced.slice(5, 10) // الأسئلة من 6 إلى 10
      }
    }
  }

  const currentQuiz = quizData[level]?.[lessonId]
  if (!currentQuiz) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-600 arabic-text">لا يوجد اختبار متاح لهذا الدرس حالياً</p>
      </div>
    )
  }

  const handleAnswerSelect = (questionId, answerIndex) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }))
  }

  const calculateScore = () => {
    let correct = 0
    currentQuiz.questions.forEach(question => {
      const correctAnswerIndex = question.options.indexOf(question.answer)
      if (selectedAnswers[question.id] === correctAnswerIndex) {
        correct++
      }
    })
    return correct
  }

  const handleSubmit = () => {
    const finalScore = calculateScore()
    setScore(finalScore)
    setShowResults(true)
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswers({})
    setShowResults(false)
    setScore(0)
  }

  const progress = ((currentQuestion + 1) / currentQuiz.questions.length) * 100

  if (showResults) {
    const percentage = (score / currentQuiz.questions.length) * 100
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Trophy className="h-16 w-16 text-yellow-500" />
          </div>
          <CardTitle className="text-2xl arabic-text">نتائج الاختبار</CardTitle>
          <CardDescription className="arabic-text">
            لقد أكملت اختبار: {currentQuiz.title}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-blue-600 mb-2">
              {score} / {currentQuiz.questions.length}
            </div>
            <div className="text-lg text-gray-600 arabic-text">
              نسبة النجاح: {percentage.toFixed(0)}%
            </div>
            <Progress value={percentage} className="mt-4" />
          </div>

          <div className="space-y-4">
            {currentQuiz.questions.map((question, index) => {
              const userAnswer = selectedAnswers[question.id]
              const correctAnswerIndex = question.options.indexOf(question.answer)
              const isCorrect = userAnswer === correctAnswerIndex
              return (
                <div key={question.id} className="border rounded-lg p-4">
                  <div className="flex items-start space-x-3 space-x-reverse">
                    {isCorrect ? (
                      <CheckCircle className="h-5 w-5 text-green-500 mt-1" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500 mt-1" />
                    )}
                    <div className="flex-1">
                      <p className="font-medium arabic-text mb-2">
                        {index + 1}. {question.question}
                      </p>
                      <p className="text-sm text-gray-600 arabic-text mb-2">
                        إجابتك: {question.options[userAnswer]}
                      </p>
                      {!isCorrect && (
                        <p className="text-sm text-green-600 arabic-text mb-2">
                          الإجابة الصحيحة: {question.answer}
                        </p>
                      )}
                      <div className="bg-blue-50 p-3 rounded-lg mb-2">
                        <div className="flex items-center gap-2 mb-1">
                          <BookOpen className="h-4 w-4 text-blue-600" />
                          <span className="text-sm font-medium text-blue-600 arabic-text">الشرح:</span>
                        </div>
                        <p className="text-sm text-blue-700 arabic-text">
                          {question.explanation}
                        </p>
                      </div>
                      {!isCorrect && question.law && (
                        <div className="bg-purple-50 p-3 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <BookOpen className="h-4 w-4 text-purple-600" />
                            <span className="text-sm font-medium text-purple-600 arabic-text">القانون ذو الصلة:</span>
                          </div>
                          <p className="text-sm text-purple-700 arabic-text">
                            {question.law}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          <div className="flex justify-center space-x-4 space-x-reverse">
            <Button onClick={resetQuiz} variant="outline" className="arabic-text">
              <RotateCcw className="ml-2 h-4 w-4" />
              إعادة المحاولة
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  const question = currentQuiz.questions[currentQuestion]

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center mb-4">
          <CardTitle className="arabic-text">{currentQuiz.title}</CardTitle>
          <Badge variant="secondary" className="arabic-text">
            {currentQuestion + 1} / {currentQuiz.questions.length}
          </Badge>
        </div>
        <Progress value={progress} className="h-2" />
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-lg font-medium mb-4 arabic-text">
            {question.question}
          </h3>
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <Button
                key={index}
                variant={selectedAnswers[question.id] === index ? "default" : "outline"}
                className="w-full text-right justify-start arabic-text"
                onClick={() => handleAnswerSelect(question.id, index)}
              >
                <span className="ml-2">{String.fromCharCode(65 + index)}.</span>
                {option}
              </Button>
            ))}
          </div>
        </div>

        <div className="flex justify-between">
          <Button
            onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
            disabled={currentQuestion === 0}
            variant="outline"
            className="arabic-text"
          >
            السؤال السابق
          </Button>

          {currentQuestion === currentQuiz.questions.length - 1 ? (
            <Button
              onClick={handleSubmit}
              disabled={selectedAnswers[question.id] === undefined}
              className="arabic-text"
            >
              إنهاء الاختبار
            </Button>
          ) : (
            <Button
              onClick={() => setCurrentQuestion(Math.min(currentQuiz.questions.length - 1, currentQuestion + 1))}
              disabled={selectedAnswers[question.id] === undefined}
              className="arabic-text"
            >
              السؤال التالي
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

export default QuizComponent


