import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, Clock, Trophy, Star, Target } from 'lucide-react';

const QuizSystem = ({ level, chapter, lesson, type = 'lesson' }) => {
  const [currentQuiz, setCurrentQuiz] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(null);
  const [quizStarted, setQuizStarted] = useState(false);

  // بيانات الاختبارات
  const quizData = {
    beginner: {
      lesson: [
        {
          id: 1,
          title: "اختبار: ما هي الفيزياء؟",
          timeLimit: 300, // 5 دقائق
          questions: [
            {
              id: 1,
              question: "ما هو تعريف الفيزياء؟",
              options: [
                "علم يدرس المادة والطاقة والتفاعلات بينهما",
                "علم يدرس الكائنات الحية فقط",
                "علم يدرس التفاعلات الكيميائية",
                "علم يدرس الأرقام والحسابات"
              ],
              correct: 0,
              explanation: "الفيزياء هي العلم الذي يدرس المادة والطاقة والتفاعلات بينهما، وهي أساس جميع العلوم الطبيعية."
            },
            {
              id: 2,
              question: "أي من التالي يعتبر من فروع الفيزياء؟",
              options: [
                "الميكانيكا",
                "علم النبات",
                "الكيمياء العضوية",
                "علم الجيولوجيا"
              ],
              correct: 0,
              explanation: "الميكانيكا هي أحد الفروع الرئيسية للفيزياء التي تدرس حركة الأجسام والقوى المؤثرة عليها."
            },
            {
              id: 3,
              question: "ما هي وحدة قياس الطول في النظام الدولي؟",
              options: [
                "السنتيمتر",
                "المتر",
                "الكيلومتر",
                "البوصة"
              ],
              correct: 1,
              explanation: "المتر هو الوحدة الأساسية لقياس الطول في النظام الدولي للوحدات (SI)."
            },
            {
              id: 4,
              question: "أي من التالي يمثل كمية فيزيائية أساسية؟",
              options: [
                "السرعة",
                "القوة",
                "الكتلة",
                "الطاقة"
              ],
              correct: 2,
              explanation: "الكتلة هي كمية فيزيائية أساسية، بينما السرعة والقوة والطاقة هي كميات مشتقة."
            },
            {
              id: 5,
              question: "ما هو الهدف الرئيسي من دراسة الفيزياء؟",
              options: [
                "حفظ القوانين والمعادلات",
                "فهم كيفية عمل الكون والطبيعة",
                "الحصول على درجات عالية",
                "تعلم الرياضيات"
              ],
              correct: 1,
              explanation: "الهدف الرئيسي من دراسة الفيزياء هو فهم كيفية عمل الكون والطبيعة من حولنا."
            }
          ]
        },
        {
          id: 2,
          title: "اختبار: الوحدات والقياسات",
          timeLimit: 420, // 7 دقائق
          questions: [
            {
              id: 1,
              question: "كم عدد الكميات الفيزيائية الأساسية في النظام الدولي؟",
              options: ["5", "6", "7", "8"],
              correct: 2,
              explanation: "يوجد 7 كميات فيزيائية أساسية في النظام الدولي: الطول، الكتلة، الزمن، التيار الكهربائي، درجة الحرارة، كمية المادة، وشدة الإضاءة."
            },
            {
              id: 2,
              question: "ما هي وحدة قياس الزمن في النظام الدولي؟",
              options: ["الدقيقة", "الساعة", "الثانية", "اليوم"],
              correct: 2,
              explanation: "الثانية هي الوحدة الأساسية لقياس الزمن في النظام الدولي."
            },
            {
              id: 3,
              question: "إذا كانت سرعة جسم 20 م/ث، فكم تساوي بالكيلومتر/ساعة؟",
              options: ["72 كم/ساعة", "20 كم/ساعة", "36 كم/ساعة", "54 كم/ساعة"],
              correct: 0,
              explanation: "لتحويل من م/ث إلى كم/ساعة نضرب في 3.6: 20 × 3.6 = 72 كم/ساعة"
            }
          ]
        }
      ],
      chapter: [
        {
          id: 1,
          title: "اختبار الفصل الأول: أساسيات الفيزياء",
          timeLimit: 900, // 15 دقيقة
          questions: [
            // أسئلة شاملة للفصل الأول
          ]
        }
      ],
      challenge: [
        {
          id: 1,
          title: "تحدي المستوى المبتدئ",
          timeLimit: 1200, // 20 دقيقة
          questions: [
            // أسئلة تحدي للمستوى المبتدئ
          ]
        }
      ]
    },
    intermediate: {
      lesson: [
        {
          id: 1,
          title: "اختبار: الميكانيكا الكلاسيكية المتقدمة",
          timeLimit: 600,
          questions: [
            {
              id: 1,
              question: "ما هو قانون نيوتن الثاني؟",
              options: [
                "F = ma",
                "F = mv",
                "F = m/a",
                "F = a/m"
              ],
              correct: 0,
              explanation: "قانون نيوتن الثاني ينص على أن القوة تساوي الكتلة مضروبة في التسارع (F = ma)."
            }
          ]
        }
      ]
    },
    advanced: {
      lesson: [
        {
          id: 1,
          title: "اختبار: النسبية الخاصة",
          timeLimit: 900,
          questions: [
            {
              id: 1,
              question: "ما هي سرعة الضوء في الفراغ؟",
              options: [
                "3 × 10⁸ م/ث",
                "3 × 10⁶ م/ث",
                "3 × 10¹⁰ م/ث",
                "3 × 10⁴ م/ث"
              ],
              correct: 0,
              explanation: "سرعة الضوء في الفراغ هي 3 × 10⁸ متر في الثانية، وهي ثابت فيزيائي مهم."
            }
          ]
        }
      ]
    }
  };

  useEffect(() => {
    if (level && quizData[level] && quizData[level][type]) {
      const quiz = quizData[level][type][0]; // أول اختبار متاح
      setCurrentQuiz(quiz);
    }
  }, [level, type]);

  useEffect(() => {
    if (timeLeft > 0 && quizStarted && !showResult) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && quizStarted) {
      handleQuizEnd();
    }
  }, [timeLeft, quizStarted, showResult]);

  const startQuiz = () => {
    setQuizStarted(true);
    setTimeLeft(currentQuiz.timeLimit);
    setCurrentQuestion(0);
    setAnswers([]);
    setScore(0);
    setShowResult(false);
  };

  const handleAnswerSelect = (answerIndex) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    const newAnswers = [...answers];
    const isCorrect = selectedAnswer === currentQuiz.questions[currentQuestion].correct;
    const questionScore = isCorrect ? 1 : 0; // درجة واحدة لكل سؤال صحيح
    
    newAnswers[currentQuestion] = {
      selected: selectedAnswer,
      correct: currentQuiz.questions[currentQuestion].correct,
      isCorrect: isCorrect,
      score: questionScore,
      law: currentQuiz.questions[currentQuestion].law
    };
    setAnswers(newAnswers);

    if (isCorrect) {
      setScore(score + questionScore);
    }

    if (currentQuestion < currentQuiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      handleQuizEnd();
    }
  };

  const handleQuizEnd = () => {
    setQuizStarted(false);
    setShowResult(true);
  };

  const resetQuiz = () => {
    setQuizStarted(false);
    setShowResult(false);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setAnswers([]);
    setScore(0);
    setTimeLeft(null);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getScoreColor = (percentage) => {
    if (percentage >= 80) return 'text-green-600';
    if (percentage >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadge = (percentage) => {
    if (percentage >= 90) return { text: 'ممتاز', color: 'bg-green-500' };
    if (percentage >= 80) return { text: 'جيد جداً', color: 'bg-blue-500' };
    if (percentage >= 70) return { text: 'جيد', color: 'bg-yellow-500' };
    if (percentage >= 60) return { text: 'مقبول', color: 'bg-orange-500' };
    return { text: 'يحتاج تحسين', color: 'bg-red-500' };
  };

  if (!currentQuiz) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="p-8 text-center">
          <Target className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-xl font-bold mb-2">لا توجد اختبارات متاحة</h3>
          <p className="text-gray-600">سيتم إضافة المزيد من الاختبارات قريباً</p>
        </CardContent>
      </Card>
    );
  }

  if (showResult) {
    const percentage = Math.round((score / currentQuiz.questions.length) * 100);
    const badge = getScoreBadge(percentage);

    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Trophy className="w-16 h-16 text-yellow-500" />
          </div>
          <CardTitle className="text-2xl">نتائج الاختبار</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className={`text-4xl font-bold mb-2 ${getScoreColor(percentage)}`}>
              {score}/{currentQuiz.questions.length}
            </div>
            <div className={`text-2xl font-bold mb-4 ${getScoreColor(percentage)}`}>
              {percentage}%
            </div>
            <Badge className={`${badge.color} text-white px-4 py-2 text-lg`}>
              {badge.text}
            </Badge>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold">مراجعة الإجابات:</h3>
            {currentQuiz.questions.map((question, index) => (
              <Card key={question.id} className="p-4">
                <div className="flex items-start gap-3">
                  {answers[index]?.isCorrect ? (
                    <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-500 mt-1" />
                  )}
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <p className="font-medium">{question.question}</p>
                      <Badge className={`${answers[index]?.isCorrect ? 'bg-green-500' : 'bg-red-500'} text-white`}>
                        {answers[index]?.score || 0}/1 نقطة
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      <strong>إجابتك:</strong> {question.options[answers[index]?.selected]}
                    </p>
                    {!answers[index]?.isCorrect && (
                      <p className="text-sm text-green-600 mb-2">
                        <strong>الإجابة الصحيحة:</strong> {question.options[question.correct]}
                      </p>
                    )}
                    <div className="bg-blue-50 p-3 rounded-lg mb-2">
                      <p className="text-sm text-blue-800">
                        <strong>📚 الشرح:</strong> {question.explanation}
                      </p>
                    </div>
                    {!answers[index]?.isCorrect && question.law && (
                      <div className="bg-purple-50 p-3 rounded-lg">
                        <p className="text-sm text-purple-800">
                          <strong>⚖️ القانون ذو الصلة:</strong> {question.law}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="flex gap-4 justify-center">
            <Button onClick={resetQuiz} variant="outline">
              إعادة الاختبار
            </Button>
            <Button onClick={() => window.location.reload()}>
              العودة للدروس
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!quizStarted) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Star className="w-16 h-16 text-blue-500" />
          </div>
          <CardTitle className="text-2xl">{currentQuiz.title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{currentQuiz.questions.length}</div>
              <div className="text-sm text-gray-600">سؤال</div>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{formatTime(currentQuiz.timeLimit)}</div>
              <div className="text-sm text-gray-600">الوقت المحدد</div>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">80%</div>
              <div className="text-sm text-gray-600">للنجاح</div>
            </div>
          </div>

          <div className="text-center">
            <h3 className="text-lg font-bold mb-2">تعليمات الاختبار:</h3>
            <ul className="text-right space-y-2 max-w-md mx-auto">
              <li>• اقرأ كل سؤال بعناية قبل الإجابة</li>
              <li>• لديك وقت محدد لإنهاء الاختبار</li>
              <li>• يمكنك إعادة الاختبار في أي وقت</li>
              <li>• ستحصل على شرح للإجابات في النهاية</li>
            </ul>
          </div>

          <div className="text-center">
            <Button onClick={startQuiz} size="lg" className="px-8">
              بدء الاختبار
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const currentQ = currentQuiz.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / currentQuiz.questions.length) * 100;

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            <span className="font-mono text-lg">{formatTime(timeLeft)}</span>
          </div>
          <div className="text-sm text-gray-600">
            السؤال {currentQuestion + 1} من {currentQuiz.questions.length}
          </div>
        </div>
        <Progress value={progress} className="w-full" />
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-xl font-bold mb-4">{currentQ.question}</h3>
          <div className="space-y-3">
            {currentQ.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                className={`w-full p-4 text-right rounded-lg border-2 transition-all ${
                  selectedAnswer === index
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                    selectedAnswer === index ? 'border-blue-500 bg-blue-500' : 'border-gray-300'
                  }`}>
                    {selectedAnswer === index && (
                      <div className="w-3 h-3 rounded-full bg-white"></div>
                    )}
                  </div>
                  <span>{option}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
            disabled={currentQuestion === 0}
          >
            السؤال السابق
          </Button>
          <Button
            onClick={handleNextQuestion}
            disabled={selectedAnswer === null}
          >
            {currentQuestion === currentQuiz.questions.length - 1 ? 'إنهاء الاختبار' : 'السؤال التالي'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default QuizSystem;



