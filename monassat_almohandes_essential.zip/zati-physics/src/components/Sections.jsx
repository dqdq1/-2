import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Zap, Atom, Thermometer, Orbit } from 'lucide-react'

const Sections = () => {
  const sections = [
    {
      id: 1,
      title: 'الميكانيكا الكلاسيكية',
      description: 'تعلم قوانين الحركة والقوى والطاقة في عالم الفيزياء الكلاسيكية',
      icon: <Orbit className="h-12 w-12 text-blue-600" />,
      topics: ['قوانين نيوتن', 'الحركة والسرعة', 'الشغل والطاقة', 'الزخم والتصادمات'],
      progress: 75,
      lessons: 25,
      color: 'from-blue-500 to-blue-700'
    },
    {
      id: 2,
      title: 'الكهرومغناطيسية',
      description: 'اكتشف أسرار الكهرباء والمغناطيسية والموجات الكهرومغناطيسية',
      icon: <Zap className="h-12 w-12 text-yellow-600" />,
      topics: ['المجال الكهربائي', 'المجال المغناطيسي', 'الدوائر الكهربائية', 'معادلات ماكسويل'],
      progress: 45,
      lessons: 30,
      color: 'from-yellow-500 to-yellow-700'
    },
    {
      id: 3,
      title: 'الديناميكا الحرارية',
      description: 'فهم قوانين الحرارة والطاقة الحرارية والآلات الحرارية',
      icon: <Thermometer className="h-12 w-12 text-red-600" />,
      topics: ['القانون الأول', 'القانون الثاني', 'الإنتروبيا', 'الآلات الحرارية'],
      progress: 30,
      lessons: 20,
      color: 'from-red-500 to-red-700'
    },
    {
      id: 4,
      title: 'الفيزياء الحديثة',
      description: 'استكشف عالم النسبية وميكانيكا الكم والفيزياء النووية',
      icon: <Atom className="h-12 w-12 text-purple-600" />,
      topics: ['النسبية الخاصة', 'ميكانيكا الكم', 'الفيزياء النووية', 'فيزياء الجسيمات'],
      progress: 15,
      lessons: 35,
      color: 'from-purple-500 to-purple-700'
    }
  ]

  return (
    <section id="sections" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4 arabic-text">
            أقسام الفيزياء
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto arabic-text">
            اختر القسم الذي تريد تعلمه وابدأ رحلتك في اكتشاف أسرار الفيزياء
          </p>
        </div>

        {/* Sections Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {sections.map((section) => (
            <Card key={section.id} className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 physics-card">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${section.color}`}>
                    {section.icon}
                  </div>
                  <div className="text-left">
                    <div className="text-sm text-gray-500 arabic-text">{section.lessons} درس</div>
                    <div className="text-sm text-gray-500 arabic-text">
                      {section.progress}% مكتمل
                    </div>
                  </div>
                </div>
                <CardTitle className="text-2xl font-bold text-gray-800 arabic-text">
                  {section.title}
                </CardTitle>
                <CardDescription className="text-gray-600 arabic-text text-lg">
                  {section.description}
                </CardDescription>
              </CardHeader>

              <CardContent>
                {/* Progress Bar */}
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700 arabic-text">التقدم</span>
                    <span className="text-sm font-medium text-gray-700">{section.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`bg-gradient-to-r ${section.color} h-2 rounded-full transition-all duration-300`}
                      style={{ width: `${section.progress}%` }}
                    ></div>
                  </div>
                </div>

                {/* Topics */}
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-800 mb-3 arabic-text">المواضيع الرئيسية:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {section.topics.map((topic, index) => (
                      <div key={index} className="text-sm text-gray-600 arabic-text flex items-center">
                        <div className="w-2 h-2 bg-blue-500 rounded-full ml-2"></div>
                        {topic}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Button */}
                <Button className="w-full group-hover:bg-blue-700 transition-colors arabic-text">
                  ابدأ التعلم
                  <ArrowLeft className="mr-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <p className="text-lg text-gray-600 mb-6 arabic-text">
            هل تريد البدء من الأساسيات؟
          </p>
          <Button size="lg" variant="outline" className="arabic-text">
            دليل المبتدئين
            <ArrowLeft className="mr-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  )
}

export default Sections

